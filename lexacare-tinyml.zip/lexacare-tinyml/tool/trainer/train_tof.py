"""
trainer/train_tof.py
====================

Entraînement CNN 2D sur frames 8x32 (4 capteurs VL53L8CX en paysage).

Architecture : très légère (~10-30 kB)
    Input : (8, 32, 1) normalisé [0..1]
    → Conv2D(8, 3) + ReLU + MaxPool
    → Conv2D(16, 3) + ReLU
    → GlobalAveragePooling2D
    → Dense(N_CLASSES, softmax)

Classes cibles (à adapter selon ce que tu annotes) :
    0 = debout
    1 = assis
    2 = allongé (normal, ex: lit)
    3 = chute (posture anormale au sol)

Dataset layout :
    datasets/tof/
        debout/
            20250420_103000.npz  (distances uint16 shape (N, 4, 8, 8))
        assis/
        allonge/
        chute/
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
from rich import print as rprint


MAX_DIST_MM = 4000.0


def _normalize_and_reshape(frames: np.ndarray) -> np.ndarray:
    """
    frames : (N, 4, 8, 8) uint16
    → (N, 8, 32, 1) float32 [0..1] — 4 capteurs côte à côte = 8×32

    Doit correspondre EXACTEMENT à normalize_and_reshape() dans task_vision.c
    """
    N = frames.shape[0]
    out = np.zeros((N, 8, 32, 1), dtype=np.float32)
    for sensor in range(4):
        block = frames[:, sensor, :, :].astype(np.float32) / MAX_DIST_MM
        block = np.clip(block, 0.0, 1.0)
        out[:, :, sensor*8:(sensor+1)*8, 0] = block
    return out


def build_dataset(dataset_dir: Path):
    labels = sorted([p.name for p in dataset_dir.iterdir() if p.is_dir()])
    rprint(f"Classes détectées : {labels}")

    X_parts, y_parts = [], []
    for label_id, label in enumerate(labels):
        for npz in (dataset_dir / label).glob("*.npz"):
            data = np.load(npz)
            frames = data["distances"]   # (N, 4, 8, 8)
            X_parts.append(_normalize_and_reshape(frames))
            y_parts.append(np.full(frames.shape[0], label_id, dtype=np.int32))

    X = np.concatenate(X_parts)
    y = np.concatenate(y_parts)
    rprint(f"Dataset : X={X.shape}, y distribution = {np.bincount(y)}")
    return X, y, labels


def build_model(n_classes: int):
    import tensorflow as tf
    L = tf.keras.layers
    return tf.keras.Sequential([
        L.Input(shape=(8, 32, 1)),
        L.Conv2D(8, 3, activation="relu", padding="same"),
        L.MaxPool2D(2),
        L.Conv2D(16, 3, activation="relu", padding="same"),
        L.GlobalAveragePooling2D(),
        L.Dense(n_classes, activation="softmax"),
    ])


def _representative_dataset_gen(X_train: np.ndarray):
    def gen():
        idx = np.random.choice(len(X_train), min(500, len(X_train)), replace=False)
        for i in idx:
            yield [X_train[i:i+1].astype(np.float32)]
    return gen


def train(dataset_dir: Path, output_tflite: Path, epochs: int = 40,
          batch_size: int = 32, val_split: float = 0.2) -> None:
    import tensorflow as tf

    X, y, labels = build_dataset(dataset_dir)
    rng = np.random.default_rng(42)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]
    n_val = int(len(X) * val_split)
    X_val, y_val = X[:n_val], y[:n_val]
    X_train, y_train = X[n_val:], y[n_val:]

    model = build_model(len(labels))
    model.compile(optimizer="adam",
                  loss="sparse_categorical_crossentropy",
                  metrics=["accuracy"])
    model.summary()
    model.fit(X_train, y_train, validation_data=(X_val, y_val),
              epochs=epochs, batch_size=batch_size, verbose=2)

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = _representative_dataset_gen(X_train)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8
    tflite = converter.convert()

    output_tflite.parent.mkdir(parents=True, exist_ok=True)
    output_tflite.write_bytes(tflite)
    output_tflite.with_suffix(".labels.txt").write_text("\n".join(labels))
    rprint(f"[green]✓[/] {output_tflite} ({len(tflite)} bytes)")
