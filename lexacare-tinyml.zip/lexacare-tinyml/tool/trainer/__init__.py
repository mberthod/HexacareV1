"""Training pipelines for LexaCare TinyML (audio KWS + ToF fall detection)."""
