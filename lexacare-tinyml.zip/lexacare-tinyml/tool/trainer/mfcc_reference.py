"""
trainer/mfcc_reference.py
=========================

Référence Python du MFCC implémenté en C dans `firmware/components/mfcc_dsp/`.

⚠️  TOUT changement ici DOIT être répercuté dans `mfcc_dsp.c` et réciproquement,
    sinon ton modèle entraîné en Python ne reconnaîtra rien sur l'ESP32.

La fonction `compute_mfcc_reference` reproduit EXACTEMENT (jusqu'à l'ordre des
opérations flottantes) le pipeline du firmware :

    1. Normalisation int16 → float [-1, 1]
    2. Pré-emphase y[n] = x[n] - α·x[n-1] avec α=0.97, x[-1]=0
    3. Fenêtre Hamming symétrique : 0.54 - 0.46·cos(2π·n / (N-1))
    4. Zero-padding vers N_FFT = 512
    5. FFT complexe
    6. |X[k]|² pour k=0..N_FFT/2 inclus
    7. Banc Mel 40 filtres triangulaires (Slaney), f_min=20Hz, f_max=sr/2
    8. log(energy + 1e-6)
    9. DCT-II orthonormée, 13 premiers coefficients

Utilisation :
    from trainer.mfcc_reference import compute_mfcc_reference, PARAMS
    mfcc = compute_mfcc_reference(pcm_int16)   # shape (N_FRAMES, N_COEFFS)
"""

from dataclasses import dataclass
import numpy as np
from scipy.fft import dct


# === Paramètres (DOIVENT matcher lexa_config.h) =============================
@dataclass(frozen=True)
class MfccParams:
    sample_rate: int = 16000
    frame_len: int   = 512      # 32 ms
    frame_step: int  = 160      # 10 ms hop
    n_fft: int       = 512
    n_mels: int      = 40
    n_coeffs: int    = 13
    preemph: float   = 0.97
    f_min_hz: float  = 20.0
    f_max_hz: float  = 8000.0   # sr/2
    window_ms: int   = 1000

PARAMS = MfccParams()


# === Utilitaires ============================================================
def hz_to_mel(hz: np.ndarray | float) -> np.ndarray | float:
    return 2595.0 * np.log10(1.0 + hz / 700.0)

def mel_to_hz(mel: np.ndarray | float) -> np.ndarray | float:
    return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)


def build_hamming_window(n: int) -> np.ndarray:
    """Hamming symétrique (denominator = N-1), identique au C."""
    return 0.54 - 0.46 * np.cos(2.0 * np.pi * np.arange(n) / (n - 1))


def build_mel_filterbank(params: MfccParams = PARAMS) -> np.ndarray:
    """
    Retourne une matrice (n_mels, n_fft/2 + 1) : chaque ligne est un filtre
    triangulaire reconstruit analytiquement (mêmes bornes que le C).

    Attention — le C calcule les poids à la volée avec des divisions entières
    (approximation linéaire). Cette version Python mime exactement ce calcul
    en utilisant des bin_points entiers (pas interpolés).
    """
    mel_min = hz_to_mel(params.f_min_hz)
    mel_max = hz_to_mel(params.f_max_hz)
    mel_pts = np.linspace(mel_min, mel_max, params.n_mels + 2)
    hz_pts = mel_to_hz(mel_pts)
    # Conversion bin_fft entière (identique à `(int)floorf(...)` en C)
    bin_pts = np.floor((params.n_fft + 1) * hz_pts / params.sample_rate).astype(int)
    bin_pts = np.clip(bin_pts, 0, params.n_fft // 2)

    fb = np.zeros((params.n_mels, params.n_fft // 2 + 1), dtype=np.float32)
    for m in range(params.n_mels):
        start, center, end = bin_pts[m], bin_pts[m + 1], bin_pts[m + 2]
        # Montée
        for k in range(start, center):
            denom = (center - start + 1)  # +1 pour matcher la division entière C
            fb[m, k] = (k - start) / denom
        # Descente
        for k in range(center, end):
            denom = (end - center + 1)
            fb[m, k] = 1.0 - (k - center) / denom
    return fb


def build_dct_matrix(params: MfccParams = PARAMS) -> np.ndarray:
    """DCT-II orthonormée — identique au C."""
    M = np.zeros((params.n_coeffs, params.n_mels), dtype=np.float32)
    norm0 = np.sqrt(1.0 / params.n_mels)
    norm_n = np.sqrt(2.0 / params.n_mels)
    for k in range(params.n_coeffs):
        norm = norm0 if k == 0 else norm_n
        for n in range(params.n_mels):
            M[k, n] = norm * np.cos(np.pi * k * (2 * n + 1) / (2.0 * params.n_mels))
    return M


# === MFCC principal =========================================================
def compute_mfcc_reference(pcm_int16: np.ndarray,
                            params: MfccParams = PARAMS) -> np.ndarray:
    """
    Calcule le MFCC reference — sortie shape (n_frames, n_coeffs).

    pcm_int16 : np.int16 1D, longueur >= window_ms * sample_rate / 1000
    """
    if pcm_int16.dtype != np.int16:
        raise ValueError("pcm_int16 must be np.int16")

    n_window_samples = params.sample_rate * params.window_ms // 1000
    if len(pcm_int16) < n_window_samples:
        raise ValueError(f"need at least {n_window_samples} samples, got {len(pcm_int16)}")

    # On ne traite QUE la dernière fenêtre (comme le firmware)
    x = pcm_int16[-n_window_samples:].astype(np.float32) / 32768.0

    # Nombre de frames identique au C : (WIN - FRAME) / STEP + 1
    n_frames = (n_window_samples - params.frame_len) // params.frame_step + 1

    window = build_hamming_window(params.frame_len).astype(np.float32)
    mel_fb = build_mel_filterbank(params)                  # (n_mels, n_fft/2+1)
    dct_mat = build_dct_matrix(params)                      # (n_coeffs, n_mels)

    mfcc = np.zeros((n_frames, params.n_coeffs), dtype=np.float32)

    # Pré-emphase : on la fait par frame avec gestion de x[-1] comme en C.
    # x[-1] initial = 0 (le C utilise prev_sample = 0 au premier sample)
    prev = 0.0
    for f in range(n_frames):
        off = f * params.frame_step
        frame = x[off:off + params.frame_len].copy()

        # Pré-emphase (note : le C fait ça continument sur toute la fenêtre,
        # donc prev persiste entre frames)
        pre = np.empty_like(frame)
        for i in range(len(frame)):
            pre[i] = frame[i] - params.preemph * prev
            prev = frame[i]

        # Fenêtrage + zero-pad
        windowed = np.zeros(params.n_fft, dtype=np.float32)
        windowed[:params.frame_len] = pre * window

        # FFT
        X = np.fft.fft(windowed)
        power = (X.real ** 2 + X.imag ** 2)[:params.n_fft // 2 + 1]

        # Banc Mel + log
        mel_energies = mel_fb @ power.astype(np.float32)
        log_mel = np.log(mel_energies + 1e-6)

        # DCT
        mfcc[f] = dct_mat @ log_mel

    return mfcc


# === Test de cohérence ======================================================
def compute_mfcc_librosa(pcm_int16: np.ndarray,
                          params: MfccParams = PARAMS) -> np.ndarray:
    """
    Version librosa pour comparaison (ne matche PAS parfaitement le C, sert juste
    de sanity check de l'ordre de grandeur).
    """
    import librosa
    x = pcm_int16.astype(np.float32) / 32768.0
    mfcc = librosa.feature.mfcc(
        y=x, sr=params.sample_rate,
        n_mfcc=params.n_coeffs,
        n_fft=params.n_fft,
        hop_length=params.frame_step,
        win_length=params.frame_len,
        n_mels=params.n_mels,
        fmin=params.f_min_hz, fmax=params.f_max_hz,
    )
    return mfcc.T  # (n_frames, n_coeffs)


if __name__ == "__main__":
    # Self-test rapide : ton implémentation ne doit pas planter et doit
    # produire des coefficients dans un range raisonnable.
    np.random.seed(42)
    signal = (np.random.randn(16000) * 3000).astype(np.int16)  # bruit gaussien 1s
    mfcc = compute_mfcc_reference(signal)
    print(f"MFCC shape = {mfcc.shape}")
    print(f"MFCC stats : min={mfcc.min():.2f} max={mfcc.max():.2f} mean={mfcc.mean():.2f}")
    print(f"Coeff 0 (énergie) sur 5 premiers frames : {mfcc[:5, 0]}")
