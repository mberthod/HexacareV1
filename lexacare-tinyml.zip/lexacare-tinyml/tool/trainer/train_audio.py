"""
trainer/train_audio.py
======================

Entraînement KWS (Keyword Spotting) sur MFCC.

Architecture : CNN 1D léger (~50-100 kB après quantization Int8).
    Input : (N_FRAMES=97, N_COEFFS=13)
    → Conv1D(16, 3) + ReLU + MaxPool
    → Conv1D(32, 3) + ReLU + MaxPool
    → GlobalAveragePooling1D
    → Dense(N_CLASSES, softmax)

Dataset layout attendu :
    datasets/audio/
        aide/
            20250420_103000.wav  (stéréo 16kHz, plusieurs secondes)
            ...
        secours/
            ...
        _unknown/                # bruit/parole random (classe poubelle)
            ...
        _silence/                # silence (classe séparée, important pour KWS)
            ...

Le loader découpe chaque WAV en fenêtres d'1s avec overlap 50% et calcule
le MFCC avec la référence Python (golden).
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import soundfile as sf
from rich import print as rprint

from trainer.mfcc_reference import compute_mfcc_reference, PARAMS


def _load_wav_as_mono_int16(path: Path) -> np.ndarray:
    audio, sr = sf.read(path, dtype="int16")
    assert sr == PARAMS.sample_rate, f"{path} sr={sr} attendu {PARAMS.sample_rate}"
    if audio.ndim == 2:
        # Mix L+R en moyenne (identique à ce que fait le firmware mais sans gain x16
        # — le gain sera appliqué au training en post si besoin)
        audio = audio.mean(axis=1).astype(np.int16)
    return audio


def _iter_windows(audio: np.ndarray, window: int, hop: int):
    for start in range(0, len(audio) - window + 1, hop):
        yield audio[start:start + window]


def build_dataset(dataset_dir: Path):
    """Charge tous les WAVs, découpe en fenêtres 1s, calcule les MFCC."""
    labels = sorted([p.name for p in dataset_dir.iterdir() if p.is_dir()])
    rprint(f"Classes détectées : {labels}")

    X, y = [], []
    window = PARAMS.sample_rate * PARAMS.window_ms // 1000
    hop = window // 2  # 50% overlap

    for label_id, label in enumerate(labels):
        class_dir = dataset_dir / label
        for wav in class_dir.glob("*.wav"):
            audio = _load_wav_as_mono_int16(wav)
            for win in _iter_windows(audio, window, hop):
                mfcc = compute_mfcc_reference(win)
                X.append(mfcc)
                y.append(label_id)

    X = np.stack(X).astype(np.float32)    # (N, 97, 13)
    y = np.array(y, dtype=np.int32)
    rprint(f"Dataset : X={X.shape}, y distribution = {np.bincount(y)}")
    return X, y, labels


def build_model(n_frames: int, n_coeffs: int, n_classes: int):
    import tensorflow as tf
    L = tf.keras.layers
    model = tf.keras.Sequential([
        L.Input(shape=(n_frames, n_coeffs)),
        L.Conv1D(16, 3, activation="relu", padding="same"),
        L.MaxPool1D(2),
        L.Conv1D(32, 3, activation="relu", padding="same"),
        L.MaxPool1D(2),
        L.Conv1D(32, 3, activation="relu", padding="same"),
        L.GlobalAveragePooling1D(),
        L.Dense(n_classes, activation="softmax"),
    ])
    return model


def _representative_dataset_gen(X_train: np.ndarray):
    def gen():
        idx = np.random.choice(len(X_train), min(500, len(X_train)), replace=False)
        for i in idx:
            yield [X_train[i:i+1].astype(np.float32)]
    return gen


def train(dataset_dir: Path, output_tflite: Path, epochs: int = 30,
          batch_size: int = 32, val_split: float = 0.2) -> None:
    import tensorflow as tf

    X, y, labels = build_dataset(dataset_dir)

    # Shuffle + split
    rng = np.random.default_rng(42)
    perm = rng.permutation(len(X))
    X, y = X[perm], y[perm]
    n_val = int(len(X) * val_split)
    X_train, y_train = X[n_val:], y[n_val:]
    X_val, y_val = X[:n_val], y[:n_val]

    model = build_model(X.shape[1], X.shape[2], len(labels))
    model.compile(optimizer="adam",
                  loss="sparse_categorical_crossentropy",
                  metrics=["accuracy"])
    model.summary()

    model.fit(X_train, y_train,
              validation_data=(X_val, y_val),
              epochs=epochs, batch_size=batch_size, verbose=2)

    # === Conversion Int8 ===
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = _representative_dataset_gen(X_train)
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    tflite_data = converter.convert()

    output_tflite.parent.mkdir(parents=True, exist_ok=True)
    output_tflite.write_bytes(tflite_data)

    # Sauvegarde des labels à côté pour que l'exporter les embarque
    labels_path = output_tflite.with_suffix(".labels.txt")
    labels_path.write_text("\n".join(labels))

    rprint(f"[green]✓[/] {output_tflite} ({len(tflite_data)} bytes)")
    rprint(f"[green]✓[/] {labels_path}")
