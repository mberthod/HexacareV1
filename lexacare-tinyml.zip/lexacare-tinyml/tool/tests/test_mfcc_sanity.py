"""
tests/test_mfcc_sanity.py
=========================

Test de base — vérifie que la référence MFCC Python tourne et produit des
valeurs cohérentes sur un signal synthétique connu (sinusoïde 440Hz).

Usage :
    cd tool/
    python -m tests.test_mfcc_sanity
"""
import numpy as np
from trainer.mfcc_reference import compute_mfcc_reference, PARAMS


def test_sine_wave_mfcc():
    """Une sinusoïde pure doit avoir son énergie concentrée sur un coefficient."""
    sr = PARAMS.sample_rate
    t = np.arange(sr, dtype=np.float32) / sr
    sine = (np.sin(2 * np.pi * 440.0 * t) * 16000).astype(np.int16)

    mfcc = compute_mfcc_reference(sine)
    assert mfcc.shape == (97, 13), f"shape mismatch: {mfcc.shape}"
    assert not np.isnan(mfcc).any(), "NaN in MFCC output"
    print(f"✓ sine 440Hz → MFCC shape {mfcc.shape}")
    print(f"  coeff 0 (énergie) moyen : {mfcc[:, 0].mean():.3f}")
    print(f"  coeff 0 std : {mfcc[:, 0].std():.3f} (doit être faible, signal stationnaire)")


def test_silence_mfcc():
    """Le silence doit donner des coefficients bas et stables."""
    silence = np.zeros(16000, dtype=np.int16)
    mfcc = compute_mfcc_reference(silence)
    assert mfcc.shape == (97, 13)
    # Coeff 0 = log(energy) → pour silence, log(1e-6) * norm = très négatif
    print(f"✓ silence → coeff 0 = {mfcc[0, 0]:.2f} (doit être très négatif, ~-13)")


def test_noise_mfcc():
    """Bruit blanc — spectre plat, coefficients décroissants en magnitude."""
    rng = np.random.default_rng(42)
    noise = (rng.standard_normal(16000) * 3000).astype(np.int16)
    mfcc = compute_mfcc_reference(noise)
    assert mfcc.shape == (97, 13)
    print(f"✓ bruit blanc → coeff 0 moyen {mfcc[:, 0].mean():.2f}")


if __name__ == "__main__":
    test_sine_wave_mfcc()
    test_silence_mfcc()
    test_noise_mfcc()
    print("\nAll MFCC sanity tests passed.")
