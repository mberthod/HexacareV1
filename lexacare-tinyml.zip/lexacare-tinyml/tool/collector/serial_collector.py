"""
collector/serial_collector.py
==============================

Capture datasets depuis l'ESP32 flashé en mode capture (env `capture_mode`).

Protocole série (USB CDC @ 115200, mais typiquement bien plus rapide car CDC) :

    Frame audio (stéréo 16kHz 16-bit) :
        Header  : 0xA5 0xA5 0xA5 0xA5  (magic)
        Type    : 0x01  (audio)
        Length  : uint32 little-endian (nombre de samples stéréo = pairs)
        Payload : length * 4 bytes (int16 L, int16 R, ...)
        CRC     : uint32 little-endian (CRC32 du payload)

    Frame ToF :
        Header  : 0xA5 0xA5 0xA5 0xA5
        Type    : 0x02  (tof)
        Length  : uint32 = 256 (pixels)
        Payload : 256 * 2 bytes (uint16 mm)
        CRC     : uint32

Sortie :
    datasets/audio/<label>/<timestamp>.wav
    datasets/tof/<label>/<timestamp>.npz  (array uint16 shape (N, 4, 8, 8))

Exemple :
    lexacare collect audio -p /dev/ttyACM0 -l aide -d 20
"""
from __future__ import annotations

import struct
import time
import zlib
from datetime import datetime
from pathlib import Path
from typing import Iterator

import numpy as np
import serial
import soundfile as sf
from rich import print as rprint
from rich.progress import Progress, BarColumn, TextColumn, TimeRemainingColumn


MAGIC = b"\xA5\xA5\xA5\xA5"
TYPE_AUDIO = 0x01
TYPE_TOF   = 0x02

SERIAL_BAUD = 921600  # ESP32-S3 USB CDC est largement capable


class FrameError(Exception):
    pass


def _read_exact(ser: serial.Serial, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        chunk = ser.read(n - len(buf))
        if not chunk:
            raise FrameError("serial read timeout")
        buf.extend(chunk)
    return bytes(buf)


def _find_magic(ser: serial.Serial) -> None:
    """Resynchronise sur le prochain magic byte."""
    window = bytearray(4)
    while True:
        b = ser.read(1)
        if not b:
            raise FrameError("timeout searching magic")
        window.pop(0)
        window.append(b[0])
        if bytes(window) == MAGIC:
            return


def read_frames(ser: serial.Serial) -> Iterator[tuple[int, bytes]]:
    """Générateur qui yield (type, payload) pour chaque frame valide."""
    while True:
        _find_magic(ser)
        header = _read_exact(ser, 1 + 4)       # type + length
        frame_type = header[0]
        length = struct.unpack("<I", header[1:])[0]
        payload = _read_exact(ser, length * (4 if frame_type == TYPE_AUDIO else 2))
        crc_bytes = _read_exact(ser, 4)
        crc_recv = struct.unpack("<I", crc_bytes)[0]
        crc_calc = zlib.crc32(payload) & 0xFFFFFFFF
        if crc_recv != crc_calc:
            rprint(f"[red]CRC mismatch[/] — frame dropped")
            continue
        yield frame_type, payload


# ============================================================================
# AUDIO
# ============================================================================
def collect_audio_cmd(port: str, label: str, duration: int, out_dir: Path) -> None:
    out_dir = Path(out_dir) / label
    out_dir.mkdir(parents=True, exist_ok=True)

    rprint(f"[cyan]Ouvrant[/] {port} @ {SERIAL_BAUD}")
    ser = serial.Serial(port, SERIAL_BAUD, timeout=2.0)
    time.sleep(0.3)   # délai de settle
    ser.reset_input_buffer()

    samples_l: list[np.ndarray] = []
    samples_r: list[np.ndarray] = []
    deadline = time.monotonic() + duration
    total_samples = 0
    target_samples = 16000 * duration

    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total} samples"),
        TimeRemainingColumn(),
    ) as prog:
        task = prog.add_task(f"Capture audio '{label}'", total=target_samples)
        for frame_type, payload in read_frames(ser):
            if frame_type != TYPE_AUDIO:
                continue
            # payload = int16 entrelacé [L0 R0 L1 R1 ...]
            arr = np.frombuffer(payload, dtype=np.int16).reshape(-1, 2)
            samples_l.append(arr[:, 0].copy())
            samples_r.append(arr[:, 1].copy())
            total_samples += arr.shape[0]
            prog.update(task, completed=min(total_samples, target_samples))
            if time.monotonic() >= deadline:
                break

    ser.close()

    L = np.concatenate(samples_l)[:target_samples]
    R = np.concatenate(samples_r)[:target_samples]
    stereo = np.stack([L, R], axis=1)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    wav_path = out_dir / f"{ts}.wav"
    sf.write(wav_path, stereo, 16000, subtype="PCM_16")
    rprint(f"[green]✓[/] {wav_path} ({len(L)/16000:.1f}s, {len(L)} samples)")


# ============================================================================
# ToF
# ============================================================================
def collect_tof_cmd(port: str, label: str, duration: int, out_dir: Path) -> None:
    out_dir = Path(out_dir) / label
    out_dir.mkdir(parents=True, exist_ok=True)

    rprint(f"[cyan]Ouvrant[/] {port}")
    ser = serial.Serial(port, SERIAL_BAUD, timeout=2.0)
    time.sleep(0.3)
    ser.reset_input_buffer()

    frames = []
    deadline = time.monotonic() + duration
    target_frames = 15 * duration  # 15 FPS

    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total} frames"),
    ) as prog:
        task = prog.add_task(f"Capture ToF '{label}'", total=target_frames)
        for frame_type, payload in read_frames(ser):
            if frame_type != TYPE_TOF:
                continue
            # payload = 256 × uint16 (4 capteurs × 8 × 8)
            arr = np.frombuffer(payload, dtype=np.uint16).reshape(4, 8, 8)
            frames.append(arr)
            prog.update(task, advance=1)
            if time.monotonic() >= deadline:
                break

    ser.close()

    if not frames:
        rprint("[red]Aucune frame reçue[/]")
        return

    data = np.stack(frames)   # (N, 4, 8, 8)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = out_dir / f"{ts}.npz"
    np.savez_compressed(out_path, distances=data, label=label)
    rprint(f"[green]✓[/] {out_path} (shape {data.shape})")
