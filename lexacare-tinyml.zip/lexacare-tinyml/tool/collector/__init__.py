"""Dataset collection module for LexaCare TinyML."""
from collector.serial_collector import collect_audio_cmd, collect_tof_cmd

__all__ = ["collect_audio_cmd", "collect_tof_cmd"]
