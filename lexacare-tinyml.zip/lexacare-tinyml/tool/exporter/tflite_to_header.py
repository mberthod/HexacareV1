"""
exporter/tflite_to_header.py
============================

Convertit un modèle .tflite en tableau C (.h) prêt à être compilé dans le firmware.

Équivalent du `xxd -i model.tflite` mais avec :
  - alignement mémoire sur 16 bytes (requis par TFLM pour perf)
  - commentaires avec taille, date, checksum
  - embarquement des labels de classes à côté

Le .h généré est inclus automatiquement par tflm_dual_runtime.cpp via
`__has_include()`. Pas besoin de modifier le code firmware à chaque re-export.
"""
from __future__ import annotations

from pathlib import Path
from datetime import datetime
import hashlib


BYTES_PER_LINE = 12


def convert(tflite_path: Path, header_path: Path, symbol: str) -> None:
    """
    Args:
        tflite_path : chemin vers le .tflite source
        header_path : chemin de sortie (.h)
        symbol      : nom de la variable C (ex: "audio_model_data")
    """
    data = tflite_path.read_bytes()
    md5 = hashlib.md5(data).hexdigest()

    labels_path = tflite_path.with_suffix(".labels.txt")
    labels = labels_path.read_text().splitlines() if labels_path.exists() else []

    lines = []
    lines.append(f"// AUTO-GENERATED — ne pas éditer à la main")
    lines.append(f"// Source  : {tflite_path.name}")
    lines.append(f"// Size    : {len(data)} bytes")
    lines.append(f"// MD5     : {md5}")
    lines.append(f"// Date    : {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"// Classes : {labels}")
    lines.append("")
    lines.append("#pragma once")
    lines.append("#include <stdint.h>")
    lines.append("")

    # Embarque les labels (utile pour logs firmware)
    if labels:
        lines.append(f"static const char *const {symbol}_labels[{len(labels)}] = {{")
        for l in labels:
            lines.append(f'    "{l}",')
        lines.append("};")
        lines.append(f"static const int {symbol}_num_labels = {len(labels)};")
        lines.append("")

    # Tableau principal, aligné 16 bytes
    lines.append(f"alignas(16) const unsigned char {symbol}[] = {{")
    for i in range(0, len(data), BYTES_PER_LINE):
        chunk = data[i:i + BYTES_PER_LINE]
        hex_bytes = ", ".join(f"0x{b:02x}" for b in chunk)
        lines.append(f"    {hex_bytes},")
    lines.append("};")
    lines.append(f"const unsigned int {symbol}_len = {len(data)};")
    lines.append("")

    header_path.write_text("\n".join(lines))
