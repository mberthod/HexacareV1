"""TFLite to C header exporter for LexaCare firmware."""
