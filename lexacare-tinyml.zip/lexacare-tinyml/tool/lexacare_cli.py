"""
lexacare_cli.py — point d'entrée CLI de l'outil LexaCare TinyML.

Sous-commandes :
    lexacare collect audio     capture dataset audio via USB CDC
    lexacare collect tof       capture dataset ToF
    lexacare train audio       entraîne le modèle KWS
    lexacare train tof         entraîne le modèle détection de chute
    lexacare export            .tflite → .h injecté dans firmware/main/models/
    lexacare serve             dashboard web (FastAPI) sur localhost:8000
    lexacare validate-mfcc     compare MFCC Python vs dump ESP32 (golden check)

Design : chaque sous-commande est une fonction Typer dans son propre module
pour éviter un fichier monolithique de 2000 lignes.
"""
from __future__ import annotations

import typer
from rich import print as rprint
from rich.console import Console
from pathlib import Path

from collector.serial_collector import collect_audio_cmd, collect_tof_cmd
# Imports différés dans les handlers pour éviter de charger TF au lancement
# (démarrage instantané de `lexacare --help`)

app = typer.Typer(
    name="lexacare",
    help="Pipeline TinyML locale pour LexaCare V1",
    no_args_is_help=True,
    add_completion=False,
)
collect_app = typer.Typer(name="collect", help="Capture de datasets depuis l'ESP32")
train_app = typer.Typer(name="train", help="Entraînement des modèles")
app.add_typer(collect_app)
app.add_typer(train_app)

console = Console()


# ============================================================================
# collect
# ============================================================================
@collect_app.command("audio")
def collect_audio(
    port: str = typer.Option("/dev/ttyACM0", "--port", "-p", help="Port série ESP32"),
    label: str = typer.Option(..., "--label", "-l", help="Nom de la classe"),
    duration: int = typer.Option(10, "--duration", "-d", help="Durée en secondes"),
    out_dir: Path = typer.Option(Path("../datasets/audio"), "--out", "-o"),
):
    """Capture N secondes d'audio stéréo depuis l'ESP32 (mode capture flashé)."""
    collect_audio_cmd(port=port, label=label, duration=duration, out_dir=out_dir)


@collect_app.command("tof")
def collect_tof(
    port: str = typer.Option("/dev/ttyACM0", "--port", "-p"),
    label: str = typer.Option(..., "--label", "-l", help="ex: 'debout', 'chute', 'assis'"),
    duration: int = typer.Option(30, "--duration", "-d", help="Secondes"),
    out_dir: Path = typer.Option(Path("../datasets/tof"), "--out", "-o"),
):
    """Capture frames ToF 8x32 @ 15 FPS."""
    collect_tof_cmd(port=port, label=label, duration=duration, out_dir=out_dir)


# ============================================================================
# train
# ============================================================================
@train_app.command("audio")
def train_audio(
    dataset: Path = typer.Option(Path("../datasets/audio"), "--dataset"),
    out: Path = typer.Option(Path("../trained/audio_kws.tflite"), "--out"),
    epochs: int = 30,
):
    """Entraîne un CNN KWS sur les MFCC du dataset audio."""
    from trainer.train_audio import train as train_fn
    train_fn(dataset_dir=dataset, output_tflite=out, epochs=epochs)


@train_app.command("tof")
def train_tof(
    dataset: Path = typer.Option(Path("../datasets/tof"), "--dataset"),
    out: Path = typer.Option(Path("../trained/tof_fall.tflite"), "--out"),
    epochs: int = 40,
):
    """Entraîne un CNN 2D sur les frames 8x32."""
    from trainer.train_tof import train as train_fn
    train_fn(dataset_dir=dataset, output_tflite=out, epochs=epochs)


# ============================================================================
# export
# ============================================================================
@app.command("export")
def export_models(
    audio_tflite: Path = typer.Option(Path("../trained/audio_kws.tflite")),
    vision_tflite: Path = typer.Option(Path("../trained/tof_fall.tflite")),
    target_dir: Path = typer.Option(Path("../firmware/main/models")),
):
    """Convertit les .tflite en .h et les injecte dans le firmware."""
    from exporter.tflite_to_header import convert
    target_dir.mkdir(parents=True, exist_ok=True)

    if audio_tflite.exists():
        convert(audio_tflite, target_dir / "audio_kws_int8.h", symbol="audio_model_data")
        rprint(f"[green]✓[/] {audio_tflite.name} → audio_kws_int8.h")
    else:
        rprint(f"[yellow]![/] {audio_tflite} missing, skipped")

    if vision_tflite.exists():
        convert(vision_tflite, target_dir / "vision_fall_int8.h", symbol="vision_model_data")
        rprint(f"[green]✓[/] {vision_tflite.name} → vision_fall_int8.h")
    else:
        rprint(f"[yellow]![/] {vision_tflite} missing, skipped")


# ============================================================================
# serve — web viewer (phase 3, stub)
# ============================================================================
@app.command("serve")
def serve(host: str = "127.0.0.1", port: int = 8000):
    """Dashboard web (datasets, training progress, courbes)."""
    import uvicorn
    uvicorn.run("webviewer.app:app", host=host, port=port, reload=False)


# ============================================================================
# validate-mfcc — cohérence Python vs ESP32
# ============================================================================
@app.command("validate-mfcc")
def validate_mfcc(
    wav: Path = typer.Argument(..., help="Fichier WAV 16kHz mono de test"),
    esp_dump: Path = typer.Option(None, "--esp-dump", help="Dump MFCC produit par l'ESP32 (binaire float32)"),
):
    """
    Valide que le MFCC C++ embarqué produit les mêmes coefficients que la
    référence Python — indispensable avant le training.

    Usage :
        1. Flasher firmware en mode debug-mfcc (TODO : ajouter cette option)
        2. Envoyer un WAV connu et récupérer le dump binaire
        3. `lexacare validate-mfcc test.wav --esp-dump dump.bin`
    """
    import numpy as np
    import soundfile as sf
    from trainer.mfcc_reference import compute_mfcc_reference, PARAMS

    audio, sr = sf.read(wav, dtype="int16")
    if audio.ndim > 1:
        audio = audio.mean(axis=1).astype(np.int16)
    if sr != PARAMS.sample_rate:
        rprint(f"[red]sample rate {sr} != {PARAMS.sample_rate}[/]")
        raise typer.Exit(1)

    ref = compute_mfcc_reference(audio)
    rprint(f"[green]Python MFCC[/] shape={ref.shape} stats[min={ref.min():.2f} max={ref.max():.2f}]")

    if esp_dump and esp_dump.exists():
        esp = np.fromfile(esp_dump, dtype=np.float32).reshape(ref.shape)
        delta = np.abs(ref - esp)
        rprint(f"[green]ESP32 MFCC[/] loaded")
        rprint(f"Max absolute diff : {delta.max():.4f}")
        rprint(f"Mean absolute diff : {delta.mean():.4f}")
        if delta.max() < 0.1:
            rprint("[green]✓ Cohérence ACCEPTABLE[/] (delta < 0.1)")
        else:
            rprint("[red]✗ DRIFT DÉTECTÉ[/] — vérifier mfcc_dsp.c vs mfcc_reference.py")


if __name__ == "__main__":
    app()
