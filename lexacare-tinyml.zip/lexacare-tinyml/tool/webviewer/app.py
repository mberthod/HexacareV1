"""
webviewer/app.py
================

Dashboard local — lancé via `lexacare serve`, ouvert dans ton navigateur
sur http://localhost:8000.

Fonctions V1 (cette release) :
  - Liste des datasets (audio + ToF) avec stats par classe
  - Prévisualisation MFCC d'un sample (spectrogramme)
  - Inspection d'un .tflite (taille, I/O tenseurs, ops utilisées)
  - Statut des modèles exportés dans firmware/main/models/

Fonctions V2 (plus tard) :
  - Lancement training avec stream websocket des courbes
  - Capture série en live avec visualisation des frames ToF
  - Comparateur MFCC Python vs ESP32 (drag-drop d'un dump)
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse

app = FastAPI(title="LexaCare TinyML Dashboard")

# Chemins relatifs à la racine du projet (tool/ est dans le projet)
TOOL_DIR = Path(__file__).resolve().parent.parent
ROOT_DIR = TOOL_DIR.parent
DATASETS_AUDIO = ROOT_DIR / "datasets" / "audio"
DATASETS_TOF   = ROOT_DIR / "datasets" / "tof"
TRAINED_DIR    = ROOT_DIR / "trained"
MODELS_DIR     = ROOT_DIR / "firmware" / "main" / "models"


# ============================================================================
# API JSON
# ============================================================================
@app.get("/api/datasets")
def list_datasets() -> dict[str, Any]:
    out: dict[str, Any] = {"audio": {}, "tof": {}}

    if DATASETS_AUDIO.exists():
        for cls_dir in DATASETS_AUDIO.iterdir():
            if cls_dir.is_dir():
                files = list(cls_dir.glob("*.wav"))
                total_duration = 0.0
                for f in files:
                    try:
                        info = sf.info(f)
                        total_duration += info.duration
                    except Exception:
                        pass
                out["audio"][cls_dir.name] = {
                    "files": len(files),
                    "duration_sec": round(total_duration, 1),
                }

    if DATASETS_TOF.exists():
        for cls_dir in DATASETS_TOF.iterdir():
            if cls_dir.is_dir():
                files = list(cls_dir.glob("*.npz"))
                total_frames = 0
                for f in files:
                    try:
                        with np.load(f) as data:
                            total_frames += data["distances"].shape[0]
                    except Exception:
                        pass
                out["tof"][cls_dir.name] = {
                    "files": len(files),
                    "frames": total_frames,
                }

    return out


@app.get("/api/models")
def list_models() -> dict[str, Any]:
    out = {"trained": [], "deployed": []}
    if TRAINED_DIR.exists():
        for p in TRAINED_DIR.glob("*.tflite"):
            out["trained"].append({"name": p.name, "size": p.stat().st_size})
    if MODELS_DIR.exists():
        for p in MODELS_DIR.glob("*.h"):
            out["deployed"].append({"name": p.name, "size": p.stat().st_size})
    return out


@app.get("/api/mfcc-preview")
def mfcc_preview(wav: str) -> dict[str, Any]:
    """Calcule le MFCC d'un sample et le retourne pour viz."""
    from trainer.mfcc_reference import compute_mfcc_reference

    path = Path(wav)
    if not path.exists():
        raise HTTPException(404, "WAV not found")

    audio, sr = sf.read(path, dtype="int16")
    if audio.ndim > 1:
        audio = audio.mean(axis=1).astype(np.int16)

    # Prendre la 1ère fenêtre d'1s
    win = audio[:16000] if len(audio) >= 16000 else np.pad(audio, (0, 16000 - len(audio)))
    mfcc = compute_mfcc_reference(win)

    return {
        "shape": list(mfcc.shape),
        "min": float(mfcc.min()),
        "max": float(mfcc.max()),
        "data": mfcc.tolist(),
    }


# ============================================================================
# Page HTML (single-file intentionnel — viewer minimal, pas de React)
# ============================================================================
INDEX_HTML = """<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8">
<title>LexaCare TinyML</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; margin: 2rem; color: #e0e0e0; background: #1a1a1a; }
  h1 { color: #4a9eff; border-bottom: 2px solid #4a9eff; padding-bottom: 0.5rem; }
  h2 { color: #7cc4ff; margin-top: 2rem; }
  .card { background: #252525; border: 1px solid #3a3a3a; border-radius: 6px; padding: 1rem; margin: 0.5rem 0; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #3a3a3a; }
  th { color: #4a9eff; }
  .tag-ok { background: #2d5a2d; padding: 2px 8px; border-radius: 3px; font-size: 0.85em; }
  .tag-none { background: #5a2d2d; padding: 2px 8px; border-radius: 3px; font-size: 0.85em; }
  code { background: #333; padding: 2px 6px; border-radius: 3px; }
</style></head>
<body>
<h1>LexaCare TinyML Dashboard</h1>
<p>Pipeline locale — équivalent Edge Impulse, offline total.</p>

<h2>Datasets</h2>
<div id="datasets">chargement…</div>

<h2>Modèles</h2>
<div id="models">chargement…</div>

<h2>Commandes CLI rappel</h2>
<div class="card">
  <p><code>lexacare collect audio -l aide -d 30</code> — capture 30s audio classe "aide"</p>
  <p><code>lexacare train audio</code> — entraîne le modèle KWS</p>
  <p><code>lexacare export</code> — injecte les modèles dans le firmware</p>
  <p><code>cd firmware && pio run -e inference_mode -t upload</code> — flashe le firmware</p>
</div>

<script>
async function load() {
  const ds = await fetch('/api/datasets').then(r => r.json());
  let html = '<div class="card"><h3>Audio</h3><table><tr><th>Classe</th><th>Fichiers</th><th>Durée</th></tr>';
  for (const [k, v] of Object.entries(ds.audio || {}))
    html += `<tr><td>${k}</td><td>${v.files}</td><td>${v.duration_sec}s</td></tr>`;
  html += '</table></div><div class="card"><h3>ToF</h3><table><tr><th>Classe</th><th>Fichiers</th><th>Frames</th></tr>';
  for (const [k, v] of Object.entries(ds.tof || {}))
    html += `<tr><td>${k}</td><td>${v.files}</td><td>${v.frames}</td></tr>`;
  html += '</table></div>';
  document.getElementById('datasets').innerHTML = html;

  const mdl = await fetch('/api/models').then(r => r.json());
  let mhtml = '<div class="card"><table><tr><th>Nom</th><th>Taille</th><th>Statut</th></tr>';
  for (const m of mdl.trained)
    mhtml += `<tr><td>${m.name}</td><td>${m.size} B</td><td><span class="tag-ok">entraîné</span></td></tr>`;
  for (const m of mdl.deployed)
    mhtml += `<tr><td>${m.name}</td><td>${m.size} B</td><td><span class="tag-ok">déployé firmware</span></td></tr>`;
  if (mdl.trained.length === 0 && mdl.deployed.length === 0)
    mhtml += '<tr><td colspan="3"><span class="tag-none">aucun modèle</span></td></tr>';
  mhtml += '</table></div>';
  document.getElementById('models').innerHTML = mhtml;
}
load();
</script>
</body></html>
"""

@app.get("/", response_class=HTMLResponse)
def index():
    return INDEX_HTML
