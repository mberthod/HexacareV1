"""FastAPI dashboard for LexaCare TinyML pipeline."""
