/**
 * @file mfcc_dsp.c
 * @brief MFCC sur ESP32-S3 via ESP-DSP (FFT accélérée matériellement).
 *
 * Performance cible sur S3 @ 240MHz (pour référence) :
 *   - 1s audio, 99 frames × 512 FFT = ~3-4 ms total
 *   - Bottleneck = le banc Mel (multiplication O(n_fft/2 × n_mels))
 */

#include "mfcc_dsp.h"
#include "../../main/lexa_config.h"
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "dsps_fft2r.h"
#include "dsps_wind_hann.h"
#include "dsps_mul.h"

static const char *TAG = "mfcc";

// --- Tables précalculées ---
static float *s_hamming_window = NULL;     // LEXA_MFCC_FRAME_LEN
static float *s_fft_workspace  = NULL;     // 2 × LEXA_MFCC_N_FFT (complex interleaved)
static float *s_power_spectrum = NULL;     // LEXA_MFCC_N_FFT / 2 + 1
static float *s_mel_energies   = NULL;     // LEXA_MFCC_N_MELS
static float *s_dct_matrix     = NULL;     // N_COEFFS × N_MELS

// Banc de filtres Mel stocké sous forme triangulaire creuse :
// Pour chaque filtre m, on a (start_bin, center_bin, end_bin).
// Le poids est reconstruit linéairement à l'évaluation.
typedef struct {
    uint16_t start_bin;
    uint16_t center_bin;
    uint16_t end_bin;
} mel_filter_t;
static mel_filter_t *s_mel_filters = NULL;  // LEXA_MFCC_N_MELS entries

static bool s_initialized = false;

// --- Utilitaires ---
static inline float hz_to_mel(float hz)
{
    // Formule Slaney/librosa standard
    return 2595.0f * log10f(1.0f + hz / 700.0f);
}

static inline float mel_to_hz(float mel)
{
    return 700.0f * (powf(10.0f, mel / 2595.0f) - 1.0f);
}

static void build_hamming_window(float *w, int n)
{
    // Hamming classique : w[n] = 0.54 - 0.46 * cos(2π n / (N-1))
    for (int i = 0; i < n; i++) {
        w[i] = 0.54f - 0.46f * cosf(2.0f * (float)M_PI * i / (n - 1));
    }
}

static void build_mel_filterbank(void)
{
    const int n_mels = LEXA_MFCC_N_MELS;
    const int n_fft = LEXA_MFCC_N_FFT;
    const float sr = LEXA_I2S_SAMPLE_RATE;

    // Bornes en Mel
    float mel_min = hz_to_mel(LEXA_MFCC_F_MIN_HZ);
    float mel_max = hz_to_mel(LEXA_MFCC_F_MAX_HZ);

    // n_mels+2 points équirépartis en Mel (bornes + centres)
    float mel_points[LEXA_MFCC_N_MELS + 2];
    for (int i = 0; i < n_mels + 2; i++) {
        mel_points[i] = mel_min + (mel_max - mel_min) * i / (n_mels + 1);
    }

    // Convertir en bin FFT
    uint16_t bin_points[LEXA_MFCC_N_MELS + 2];
    for (int i = 0; i < n_mels + 2; i++) {
        float hz = mel_to_hz(mel_points[i]);
        int bin = (int)floorf((n_fft + 1) * hz / sr);
        if (bin < 0) bin = 0;
        if (bin > n_fft / 2) bin = n_fft / 2;
        bin_points[i] = (uint16_t)bin;
    }

    for (int m = 0; m < n_mels; m++) {
        s_mel_filters[m].start_bin  = bin_points[m];
        s_mel_filters[m].center_bin = bin_points[m + 1];
        s_mel_filters[m].end_bin    = bin_points[m + 2];
    }
}

static void build_dct_matrix(void)
{
    // DCT-II orthonormée (comme scipy.fft.dct(type=2, norm='ortho'))
    const int n_coeffs = LEXA_MFCC_N_COEFFS;
    const int n_mels = LEXA_MFCC_N_MELS;
    const float norm0 = sqrtf(1.0f / n_mels);
    const float norm_n = sqrtf(2.0f / n_mels);

    for (int k = 0; k < n_coeffs; k++) {
        float norm = (k == 0) ? norm0 : norm_n;
        for (int n = 0; n < n_mels; n++) {
            s_dct_matrix[k * n_mels + n] =
                norm * cosf((float)M_PI * k * (2 * n + 1) / (2.0f * n_mels));
        }
    }
}

// ---------------------------------------------------------------------------
// API publique
// ---------------------------------------------------------------------------

esp_err_t mfcc_dsp_init(void)
{
    if (s_initialized) return ESP_OK;

    // Toutes les tables en DRAM interne (accès rapide, petites tailles)
    s_hamming_window = heap_caps_malloc(LEXA_MFCC_FRAME_LEN * sizeof(float),
                                         MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_fft_workspace = heap_caps_malloc(2 * LEXA_MFCC_N_FFT * sizeof(float),
                                        MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_power_spectrum = heap_caps_malloc((LEXA_MFCC_N_FFT / 2 + 1) * sizeof(float),
                                         MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_mel_energies = heap_caps_malloc(LEXA_MFCC_N_MELS * sizeof(float),
                                       MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_dct_matrix = heap_caps_malloc(LEXA_MFCC_N_COEFFS * LEXA_MFCC_N_MELS * sizeof(float),
                                     MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s_mel_filters = heap_caps_malloc(LEXA_MFCC_N_MELS * sizeof(mel_filter_t),
                                      MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);

    if (!s_hamming_window || !s_fft_workspace || !s_power_spectrum ||
        !s_mel_energies || !s_dct_matrix || !s_mel_filters) {
        ESP_LOGE(TAG, "alloc failed");
        return ESP_ERR_NO_MEM;
    }

    build_hamming_window(s_hamming_window, LEXA_MFCC_FRAME_LEN);
    build_mel_filterbank();
    build_dct_matrix();

    // Init FFT tables ESP-DSP (table sin/cos)
    esp_err_t ret = dsps_fft2r_init_fc32(NULL, LEXA_MFCC_N_FFT);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "FFT init failed: %d", ret);
        return ret;
    }

    s_initialized = true;
    ESP_LOGI(TAG, "MFCC init OK — %d mels, %d coeffs, %d frames/window",
             LEXA_MFCC_N_MELS, LEXA_MFCC_N_COEFFS, LEXA_MFCC_N_FRAMES);
    return ESP_OK;
}

esp_err_t mfcc_dsp_compute(const int16_t *audio_in, size_t n_samples, float *mfcc_out)
{
    if (!s_initialized) return ESP_ERR_INVALID_STATE;
    if (n_samples < LEXA_MFCC_FRAME_LEN) return ESP_ERR_INVALID_SIZE;

    const int frame_len = LEXA_MFCC_FRAME_LEN;
    const int frame_step = LEXA_MFCC_FRAME_STEP;
    const int n_fft = LEXA_MFCC_N_FFT;
    const int n_frames = LEXA_MFCC_N_FRAMES;
    const int n_mels = LEXA_MFCC_N_MELS;
    const int n_coeffs = LEXA_MFCC_N_COEFFS;

    // Pré-emphase : y[n] = x[n] - α·x[n-1]
    // On la fait à la volée par frame (pas de buffer séparé).
    float prev_sample = 0.0f;  // x[-1] pour le tout premier échantillon

    for (int f = 0; f < n_frames; f++) {
        int offset = f * frame_step;
        if (offset + frame_len > (int)n_samples) break;

        // 1. Pré-emphase + Hamming + zero-padding jusqu'à n_fft
        //    (format complexe entrelacé pour FFT : [re0, im0, re1, im1, ...])
        for (int i = 0; i < frame_len; i++) {
            float sample = (float)audio_in[offset + i] / 32768.0f;   // normalise [-1,1]
            float pre = sample - LEXA_MFCC_PREEMPH * prev_sample;
            prev_sample = sample;
            s_fft_workspace[2 * i]     = pre * s_hamming_window[i];  // real
            s_fft_workspace[2 * i + 1] = 0.0f;                        // imag
        }
        // Zero-pad
        for (int i = frame_len; i < n_fft; i++) {
            s_fft_workspace[2 * i]     = 0.0f;
            s_fft_workspace[2 * i + 1] = 0.0f;
        }

        // 2. FFT complexe in-place (ESP-DSP optimisé ESP-NN)
        dsps_fft2r_fc32(s_fft_workspace, n_fft);
        dsps_bit_rev_fc32(s_fft_workspace, n_fft);

        // 3. Spectre de puissance |X[k]|² pour k=0..n_fft/2
        for (int k = 0; k <= n_fft / 2; k++) {
            float re = s_fft_workspace[2 * k];
            float im = s_fft_workspace[2 * k + 1];
            s_power_spectrum[k] = re * re + im * im;
        }

        // 4. Banc Mel : pour chaque filtre, somme pondérée triangulaire
        for (int m = 0; m < n_mels; m++) {
            const mel_filter_t *mf = &s_mel_filters[m];
            float energy = 0.0f;

            // Montée : start → center
            for (uint16_t k = mf->start_bin; k < mf->center_bin; k++) {
                float w = (float)(k - mf->start_bin) /
                          (float)(mf->center_bin - mf->start_bin + 1);
                energy += s_power_spectrum[k] * w;
            }
            // Descente : center → end
            for (uint16_t k = mf->center_bin; k < mf->end_bin; k++) {
                float w = 1.0f - (float)(k - mf->center_bin) /
                                  (float)(mf->end_bin - mf->center_bin + 1);
                energy += s_power_spectrum[k] * w;
            }

            // Log avec epsilon pour éviter log(0)
            s_mel_energies[m] = logf(energy + 1e-6f);
        }

        // 5. DCT → N_COEFFS premiers cepstra
        float *frame_out = &mfcc_out[f * n_coeffs];
        for (int k = 0; k < n_coeffs; k++) {
            float acc = 0.0f;
            for (int n = 0; n < n_mels; n++) {
                acc += s_dct_matrix[k * n_mels + n] * s_mel_energies[n];
            }
            frame_out[k] = acc;
        }
    }

    return ESP_OK;
}

void mfcc_dsp_deinit(void)
{
    if (!s_initialized) return;
    dsps_fft2r_deinit_fc32();
    free(s_hamming_window);
    free(s_fft_workspace);
    free(s_power_spectrum);
    free(s_mel_energies);
    free(s_dct_matrix);
    free(s_mel_filters);
    s_initialized = false;
}
