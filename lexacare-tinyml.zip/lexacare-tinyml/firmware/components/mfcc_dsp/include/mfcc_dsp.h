/**
 * @file mfcc_dsp.h
 * @brief MFCC (Mel-Frequency Cepstral Coefficients) extraction sur ESP32-S3.
 *
 * Pipeline identique à librosa.feature.mfcc avec les paramètres de lexa_config.h :
 *   1. Pré-emphase (filtre passe-haut simple)
 *   2. Fenêtrage Hamming
 *   3. FFT réelle (ESP-DSP)
 *   4. Spectre de puissance |X|²
 *   5. Banc de filtres triangulaires Mel (40 filtres)
 *   6. log(energy + eps)
 *   7. DCT-II, 13 premiers coefficients
 *
 * La référence Python `tool/trainer/mfcc_reference.py` reproduit
 * EXACTEMENT le même calcul. Toute dérive = IA cassée.
 *
 * Analogie : c'est comme un décodeur FOC où le modèle mathématique (Park)
 * doit être bit-à-bit identique entre la simulation Matlab et le firmware C.
 * Un delta de quantification sur un sin/cos et le rotor part en diagonale.
 */
#pragma once

#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"

/**
 * @brief Initialise le banc de filtres Mel et les tables FFT.
 *        À appeler une seule fois avant `mfcc_dsp_compute()`.
 */
esp_err_t mfcc_dsp_init(void);

/**
 * @brief Calcule le MFCC d'un signal audio mono int16.
 *
 * @param audio_in       Échantillons PCM 16 bits, longueur >= LEXA_AUDIO_WINDOW_SAMPLES
 * @param n_samples      Nombre d'échantillons fournis
 * @param mfcc_out       Sortie : N_FRAMES × N_COEFFS float, ligne-majeur
 *                       Taille requise = LEXA_MFCC_N_FRAMES * LEXA_MFCC_N_COEFFS * sizeof(float)
 * @return ESP_OK ou erreur
 */
esp_err_t mfcc_dsp_compute(const int16_t *audio_in,
                           size_t n_samples,
                           float *mfcc_out);

/**
 * @brief Libère les tables internes. Rarement utilisé (le MFCC tourne jusqu'à
 *        l'extinction), mais utile pour les tests.
 */
void mfcc_dsp_deinit(void);
