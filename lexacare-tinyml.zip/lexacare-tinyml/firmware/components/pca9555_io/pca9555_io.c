/**
 * @file pca9555_io.c
 * @brief Driver I2C PCA9555 (expandeur 16 GPIO).
 *
 * Registres :
 *   0x00/0x01 : Input port 0/1
 *   0x02/0x03 : Output port 0/1
 *   0x04/0x05 : Polarity inversion 0/1
 *   0x06/0x07 : Configuration 0/1 (1 = input, 0 = output)
 */

#include "pca9555_io.h"
#include "../../main/lexa_config.h"
#include "driver/i2c_master.h"
#include "esp_log.h"

static const char *TAG = "pca9555";

#define REG_OUTPUT_0   0x02
#define REG_OUTPUT_1   0x03
#define REG_CONFIG_0   0x06
#define REG_CONFIG_1   0x07

static i2c_master_bus_handle_t s_bus = NULL;
static i2c_master_dev_handle_t s_dev = NULL;
static uint16_t s_output_cache = 0x0000;  // état courant des sorties

esp_err_t pca9555_init(void)
{
    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = -1,
        .sda_io_num = LEXA_I2C_SDA_GPIO,
        .scl_io_num = LEXA_I2C_SCL_GPIO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_cfg, &s_bus));

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address  = LEXA_PCA9555_ADDR,
        .scl_speed_hz    = LEXA_I2C_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_master_bus_add_device(s_bus, &dev_cfg, &s_dev));

    // Configurer P0-P3 en sortie (pour LPn), les autres en entrée par défaut
    uint8_t cfg_buf[3] = {REG_CONFIG_0, 0xF0, 0xFF};  // P0-P3 output, reste input
    ESP_ERROR_CHECK(i2c_master_transmit(s_dev, cfg_buf, 3, 100));

    // Tous LPn à 0 au démarrage (sécurité : capteurs OFF)
    uint8_t out_buf[3] = {REG_OUTPUT_0, 0x00, 0x00};
    ESP_ERROR_CHECK(i2c_master_transmit(s_dev, out_buf, 3, 100));
    s_output_cache = 0;

    ESP_LOGI(TAG, "PCA9555 init OK @ 0x%02X", LEXA_PCA9555_ADDR);
    return ESP_OK;
}

esp_err_t pca9555_set_tof_lpn(int idx, bool on)
{
    if (idx < 0 || idx >= LEXA_TOF_COUNT) return ESP_ERR_INVALID_ARG;
    if (on) s_output_cache |=  (1 << idx);
    else    s_output_cache &= ~(1 << idx);
    uint8_t buf[3] = {REG_OUTPUT_0,
                      (uint8_t)(s_output_cache & 0xFF),
                      (uint8_t)(s_output_cache >> 8)};
    return i2c_master_transmit(s_dev, buf, 3, 100);
}

esp_err_t pca9555_set_all_tof_lpn(bool on)
{
    if (on) s_output_cache |=  0x000F;
    else    s_output_cache &= ~0x000F;
    uint8_t buf[3] = {REG_OUTPUT_0,
                      (uint8_t)(s_output_cache & 0xFF),
                      (uint8_t)(s_output_cache >> 8)};
    return i2c_master_transmit(s_dev, buf, 3, 100);
}

esp_err_t pca9555_write_reg(uint8_t reg, uint16_t val)
{
    uint8_t buf[3] = {reg, (uint8_t)(val & 0xFF), (uint8_t)(val >> 8)};
    return i2c_master_transmit(s_dev, buf, 3, 100);
}

esp_err_t pca9555_read_reg(uint8_t reg, uint16_t *val)
{
    uint8_t rx[2] = {0};
    esp_err_t err = i2c_master_transmit_receive(s_dev, &reg, 1, rx, 2, 100);
    if (err == ESP_OK) *val = rx[0] | (rx[1] << 8);
    return err;
}
