/**
 * @file pca9555_io.h
 * @brief Expander I/O PCA9555 @ 0x20 — contrôle les LPn des 4 VL53L8CX.
 *
 * Mapping de référence (à ajuster selon ton schéma) :
 *   P0  → LPn ToF #0
 *   P1  → LPn ToF #1
 *   P2  → LPn ToF #2
 *   P3  → LPn ToF #3
 *   P4..P15 → réservés (LEDs, etc.)
 *
 * LPn actif bas : LPn=0 → capteur en veille, LPn=1 → capteur actif.
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

esp_err_t pca9555_init(void);
esp_err_t pca9555_set_tof_lpn(int idx, bool on);       // idx 0..3
esp_err_t pca9555_set_all_tof_lpn(bool on);
esp_err_t pca9555_write_reg(uint8_t reg, uint16_t val);  // bas niveau
esp_err_t pca9555_read_reg(uint8_t reg, uint16_t *val);
