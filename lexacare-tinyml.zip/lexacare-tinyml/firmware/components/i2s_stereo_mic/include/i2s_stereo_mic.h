/**
 * @file i2s_stereo_mic.h
 * @brief Driver I2S stéréo + ring buffer en PSRAM.
 *
 * Flux : 2 micros → I2S standard mode (Philips), 16kHz 16-bit, entrelacé L/R
 *        → DMA descriptors → callback → ring buffer circulaire PSRAM
 *
 * Analogie : c'est un "tampon d'entrée" comme celui d'un oscilloscope à mémoire
 * segmentée. La DMA écrit continuellement dans le ring, et n'importe quelle
 * tâche peut "photographier" la dernière fenêtre de temps sans stopper la capture.
 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"

esp_err_t i2s_stereo_mic_init(void);
esp_err_t i2s_stereo_mic_start(void);
esp_err_t i2s_stereo_mic_stop(void);

/**
 * @brief Copie la dernière fenêtre d'échantillons stéréo entrelacés.
 * @param dst       Buffer de destination (taille >= n_frames × 2 × int16)
 * @param n_frames  Nombre de paires L/R à extraire
 * @return Nombre réel de frames copiées (peut être < n_frames si capture récente)
 */
size_t i2s_stereo_mic_read_last_window(int16_t *dst, size_t n_frames);
