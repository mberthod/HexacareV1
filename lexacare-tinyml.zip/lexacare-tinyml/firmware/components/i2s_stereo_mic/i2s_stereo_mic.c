/**
 * @file i2s_stereo_mic.c
 * @brief Driver I2S stéréo avec ring buffer en PSRAM.
 *
 * Utilise l'API "new" I2S d'ESP-IDF v5 (driver/i2s_std.h) — plus propre que
 * l'ancienne, gestion DMA callback explicite.
 *
 * Note technique : la DMA écrit par paquets de dma_frame_num échantillons.
 * Entre deux DMA reads on peut perdre des samples si on n'ingère pas assez vite.
 * Dimensionnement : 16kHz × 2 canaux × 2 bytes = 64kB/s. Notre ring de 3s = 192kB.
 * DMA descriptor = 2 × 1024 frames = 4kB chacun, dma_desc_num=8 → 32kB de marge DMA.
 */

#include "i2s_stereo_mic.h"
#include "../../main/lexa_config.h"
#include <string.h>
#include "driver/i2s_std.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

static const char *TAG = "i2s_mic";

// Ring buffer stéréo entrelacé [L0 R0 L1 R1 ...] en PSRAM
static int16_t *s_ring = NULL;
static size_t   s_ring_frames = LEXA_AUDIO_RING_SAMPLES;  // en frames L/R
static volatile size_t s_write_idx = 0;                    // index d'écriture circulaire (en frames)

static i2s_chan_handle_t s_rx_chan = NULL;
static SemaphoreHandle_t s_ring_mutex = NULL;
static TaskHandle_t       s_reader_task = NULL;

static bool on_i2s_recv_done(i2s_chan_handle_t handle, i2s_event_data_t *event, void *user_ctx)
{
    // Pas de copie dans cette callback — la tâche de lecture dédiée le fait.
    // On notifie juste qu'un buffer DMA est prêt.
    BaseType_t higher_prio = pdFALSE;
    vTaskNotifyGiveFromISR(s_reader_task, &higher_prio);
    return higher_prio == pdTRUE;
}

// Tâche dédiée qui pompe l'I2S en continu et remplit le ring.
// Plus propre qu'une callback ISR qui ferait de la copie lourde.
static void reader_task(void *arg)
{
    const size_t chunk_frames = 512;                  // 512 frames = 32ms @16k
    const size_t chunk_bytes = chunk_frames * 2 * sizeof(int16_t);  // stéréo
    int16_t *tmp = heap_caps_malloc(chunk_bytes, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (!tmp) {
        ESP_LOGE(TAG, "reader alloc failed");
        vTaskDelete(NULL);
        return;
    }

    while (1) {
        size_t bytes_read = 0;
        esp_err_t err = i2s_channel_read(s_rx_chan, tmp, chunk_bytes, &bytes_read, portMAX_DELAY);
        if (err != ESP_OK || bytes_read == 0) {
            ESP_LOGW(TAG, "i2s read err=%d bytes=%u", err, (unsigned)bytes_read);
            continue;
        }

        size_t frames_read = bytes_read / (2 * sizeof(int16_t));
        xSemaphoreTake(s_ring_mutex, portMAX_DELAY);

        // Copie dans le ring avec wrap-around
        size_t start = s_write_idx;
        if (start + frames_read <= s_ring_frames) {
            memcpy(&s_ring[start * 2], tmp, frames_read * 2 * sizeof(int16_t));
        } else {
            size_t first = s_ring_frames - start;
            memcpy(&s_ring[start * 2], tmp, first * 2 * sizeof(int16_t));
            memcpy(&s_ring[0], &tmp[first * 2], (frames_read - first) * 2 * sizeof(int16_t));
        }
        s_write_idx = (start + frames_read) % s_ring_frames;
        xSemaphoreGive(s_ring_mutex);
    }
}

esp_err_t i2s_stereo_mic_init(void)
{
    s_ring = heap_caps_malloc(s_ring_frames * 2 * sizeof(int16_t), MALLOC_CAP_SPIRAM);
    if (!s_ring) {
        ESP_LOGE(TAG, "ring buffer alloc failed");
        return ESP_ERR_NO_MEM;
    }
    memset(s_ring, 0, s_ring_frames * 2 * sizeof(int16_t));

    s_ring_mutex = xSemaphoreCreateMutex();
    if (!s_ring_mutex) return ESP_ERR_NO_MEM;

    // Configuration channel I2S en mode RX standard (Philips)
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(LEXA_I2S_PORT, I2S_ROLE_MASTER);
    chan_cfg.dma_desc_num = 8;
    chan_cfg.dma_frame_num = 1024;
    chan_cfg.auto_clear = true;
    ESP_ERROR_CHECK(i2s_new_channel(&chan_cfg, NULL, &s_rx_chan));

    i2s_std_config_t std_cfg = {
        .clk_cfg  = I2S_STD_CLK_DEFAULT_CONFIG(LEXA_I2S_SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(LEXA_I2S_BITS_PER_SAMPLE,
                                                        I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = LEXA_I2S_BCLK_GPIO,
            .ws   = LEXA_I2S_WS_GPIO,
            .dout = I2S_GPIO_UNUSED,
            .din  = LEXA_I2S_DIN_GPIO,
            .invert_flags = {0},
        },
    };
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(s_rx_chan, &std_cfg));

    ESP_LOGI(TAG, "I2S init OK — ring %u frames (%u bytes) in PSRAM",
             (unsigned)s_ring_frames, (unsigned)(s_ring_frames * 4));
    return ESP_OK;
}

esp_err_t i2s_stereo_mic_start(void)
{
    // Tâche reader pinnée sur Core 0 (audio core) avec prio DMA
    xTaskCreatePinnedToCore(reader_task, "i2s_rd", 4096, NULL,
                             LEXA_PRIO_AUDIO_DMA, &s_reader_task, LEXA_CORE_AUDIO);
    ESP_ERROR_CHECK(i2s_channel_enable(s_rx_chan));
    return ESP_OK;
}

esp_err_t i2s_stereo_mic_stop(void)
{
    if (s_reader_task) { vTaskDelete(s_reader_task); s_reader_task = NULL; }
    return i2s_channel_disable(s_rx_chan);
}

size_t i2s_stereo_mic_read_last_window(int16_t *dst, size_t n_frames)
{
    if (!s_ring || !dst) return 0;
    if (n_frames > s_ring_frames) n_frames = s_ring_frames;

    xSemaphoreTake(s_ring_mutex, portMAX_DELAY);
    // On veut les n_frames AVANT s_write_idx (échantillons les plus récents)
    size_t end = s_write_idx;
    size_t start = (end + s_ring_frames - n_frames) % s_ring_frames;

    if (start + n_frames <= s_ring_frames) {
        memcpy(dst, &s_ring[start * 2], n_frames * 2 * sizeof(int16_t));
    } else {
        size_t first = s_ring_frames - start;
        memcpy(dst, &s_ring[start * 2], first * 2 * sizeof(int16_t));
        memcpy(&dst[first * 2], &s_ring[0], (n_frames - first) * 2 * sizeof(int16_t));
    }
    xSemaphoreGive(s_ring_mutex);
    return n_frames;
}
