/**
 * @file tflm_dual_runtime.cpp
 * @brief Deux runtimes TFLM isolés, arenas en PSRAM.
 *
 * IMPORTANT : les modèles .h sont inclus conditionnellement. Tant que tu n'as
 * pas encore exporté tes modèles, le code compile avec des stubs qui
 * retournent label=0 conf=0. Après ton premier `lexacare export`, les vrais
 * modèles sont injectés dans `main/models/` et repris automatiquement.
 */

#include "tflm_dual_runtime.h"
#include "../../main/lexa_config.h"
#include "esp_log.h"
#include "esp_heap_caps.h"

// --- TFLM headers ---
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"

// --- Inclusion conditionnelle des modèles ---
// Ces fichiers sont générés par `lexacare export` et placés dans main/models/
// S'ils n'existent pas encore, on utilise des stubs vides (pas d'inférence).
#if __has_include("models/audio_kws_int8.h")
  #include "models/audio_kws_int8.h"
  #define HAS_AUDIO_MODEL 1
#else
  static const unsigned char audio_model_data[] = {0};
  static const unsigned int  audio_model_data_len = 0;
#endif

#if __has_include("models/vision_fall_int8.h")
  #include "models/vision_fall_int8.h"
  #define HAS_VISION_MODEL 1
#else
  static const unsigned char vision_model_data[] = {0};
  static const unsigned int  vision_model_data_len = 0;
#endif

static const char *TAG = "tflm_dual";

// ============================================================================
// État interne : 2 arenas + 2 interpreters
// ============================================================================
namespace {
uint8_t *s_arena_audio  = nullptr;
uint8_t *s_arena_vision = nullptr;

const tflite::Model *s_model_audio  = nullptr;
const tflite::Model *s_model_vision = nullptr;

tflite::MicroInterpreter *s_interp_audio  = nullptr;
tflite::MicroInterpreter *s_interp_vision = nullptr;

// Resolver commun : on liste ici tous les ops que les modèles peuvent utiliser.
// MicroMutableOpResolver est statique → éviter de le reconstruire.
//
// Pour un KWS standard + un CNN de détection de chute, ces ops suffisent.
// Ajouter si un modèle se plaint au runtime (message "op not registered").
tflite::MicroMutableOpResolver<12> *s_resolver = nullptr;
}

extern "C" esp_err_t tflm_dual_runtime_init(void)
{
    // Allocation des arenas en PSRAM
    s_arena_audio = (uint8_t *)heap_caps_malloc(LEXA_TFLM_ARENA_AUDIO_SIZE,
                                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    s_arena_vision = (uint8_t *)heap_caps_malloc(LEXA_TFLM_ARENA_VISION_SIZE,
                                                  MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!s_arena_audio || !s_arena_vision) {
        ESP_LOGE(TAG, "arena alloc failed");
        return ESP_ERR_NO_MEM;
    }

    // Resolver partagé — palette d'ops volontairement large pour couvrir les
    // deux architectures (CNN 1D audio + CNN 2D vision).
    static tflite::MicroMutableOpResolver<12> resolver;
    resolver.AddConv2D();
    resolver.AddDepthwiseConv2D();
    resolver.AddMaxPool2D();
    resolver.AddAveragePool2D();
    resolver.AddFullyConnected();
    resolver.AddReshape();
    resolver.AddSoftmax();
    resolver.AddRelu();
    resolver.AddMean();
    resolver.AddQuantize();
    resolver.AddDequantize();
    resolver.AddLogistic();
    s_resolver = &resolver;

#ifdef HAS_AUDIO_MODEL
    s_model_audio = tflite::GetModel(audio_model_data);
    if (s_model_audio->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "audio model schema mismatch");
        return ESP_ERR_INVALID_VERSION;
    }
    static tflite::MicroInterpreter interp_a(s_model_audio, *s_resolver,
                                              s_arena_audio, LEXA_TFLM_ARENA_AUDIO_SIZE);
    s_interp_audio = &interp_a;
    if (s_interp_audio->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "audio AllocateTensors failed — arena trop petite ?");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "audio model loaded, arena used=%u / %u",
             (unsigned)s_interp_audio->arena_used_bytes(),
             (unsigned)LEXA_TFLM_ARENA_AUDIO_SIZE);
#else
    ESP_LOGW(TAG, "no audio model — run `lexacare export` and rebuild");
#endif

#ifdef HAS_VISION_MODEL
    s_model_vision = tflite::GetModel(vision_model_data);
    if (s_model_vision->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "vision model schema mismatch");
        return ESP_ERR_INVALID_VERSION;
    }
    static tflite::MicroInterpreter interp_v(s_model_vision, *s_resolver,
                                              s_arena_vision, LEXA_TFLM_ARENA_VISION_SIZE);
    s_interp_vision = &interp_v;
    if (s_interp_vision->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "vision AllocateTensors failed");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "vision model loaded, arena used=%u / %u",
             (unsigned)s_interp_vision->arena_used_bytes(),
             (unsigned)LEXA_TFLM_ARENA_VISION_SIZE);
#else
    ESP_LOGW(TAG, "no vision model — run `lexacare export` and rebuild");
#endif

    return ESP_OK;
}

// ============================================================================
// Quantisation float→int8 selon les scale/zero_point du tenseur d'entrée.
// ============================================================================
static void quantize_with_tensor(const TfLiteTensor *t, const float *in, size_t n, int8_t *out)
{
    float scale = t->params.scale;
    int zero = t->params.zero_point;
    for (size_t i = 0; i < n; i++) {
        int32_t q = (int32_t)(in[i] / scale + zero + 0.5f);
        if (q < -128) q = -128;
        if (q > 127) q = 127;
        out[i] = (int8_t)q;
    }
}

extern "C" void tflm_quantize_input_audio(const float *in, size_t n, int8_t *out)
{
    if (!s_interp_audio) { for (size_t i = 0; i < n; i++) out[i] = 0; return; }
    quantize_with_tensor(s_interp_audio->input(0), in, n, out);
}

extern "C" void tflm_quantize_input_vision(const float *in, size_t n, int8_t *out)
{
    if (!s_interp_vision) { for (size_t i = 0; i < n; i++) out[i] = 0; return; }
    quantize_with_tensor(s_interp_vision->input(0), in, n, out);
}

// ============================================================================
// Inférence : copie input, Invoke, déquantise softmax, renvoie argmax
// ============================================================================
static esp_err_t run_infer_int8(tflite::MicroInterpreter *interp,
                                 const int8_t *q_input,
                                 uint8_t *label_out, float *conf_out)
{
    if (!interp) { *label_out = 0; *conf_out = 0.0f; return ESP_ERR_INVALID_STATE; }

    TfLiteTensor *in_t = interp->input(0);
    size_t in_size = in_t->bytes;
    memcpy(in_t->data.int8, q_input, in_size);

    if (interp->Invoke() != kTfLiteOk) {
        return ESP_FAIL;
    }

    TfLiteTensor *out_t = interp->output(0);
    // On suppose sortie int8 softmax (N classes)
    int n_cls = out_t->bytes;
    float out_scale = out_t->params.scale;
    int   out_zero = out_t->params.zero_point;

    int best_idx = 0;
    int8_t best_q = out_t->data.int8[0];
    for (int i = 1; i < n_cls; i++) {
        if (out_t->data.int8[i] > best_q) {
            best_q = out_t->data.int8[i];
            best_idx = i;
        }
    }
    *label_out = (uint8_t)best_idx;
    *conf_out = (best_q - out_zero) * out_scale;  // [0..1]
    return ESP_OK;
}

extern "C" esp_err_t tflm_audio_infer(const int8_t *mfcc_input, tflm_audio_result_t *r)
{
    return run_infer_int8(s_interp_audio, mfcc_input, &r->label_id, &r->confidence);
}

extern "C" esp_err_t tflm_vision_infer(const int8_t *img_input, tflm_vision_result_t *r)
{
    return run_infer_int8(s_interp_vision, img_input, &r->label_id, &r->confidence);
}
