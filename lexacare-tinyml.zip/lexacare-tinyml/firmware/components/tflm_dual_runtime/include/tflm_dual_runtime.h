/**
 * @file tflm_dual_runtime.h
 * @brief 2 instances TFLM isolées (audio + vision) dans PSRAM.
 *
 * Pourquoi 2 instances séparées plutôt qu'une seule ?
 *   1. Isolation : un crash de parse d'un modèle ne tue pas l'autre.
 *   2. Arenas séparées = pas de compaction cross-modèle = perf déterministe.
 *   3. Possible (phase 2) de charger dynamiquement un modèle pendant que l'autre tourne.
 *
 * Modèles injectés au build via header auto-généré par `lexacare export` :
 *     models/audio_kws_int8.h   (tableau `audio_model_data`)
 *     models/vision_fall_int8.h (tableau `vision_model_data`)
 */
#pragma once

#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint8_t label_id;       // classe prédite
    float   confidence;     // softmax max [0..1]
} tflm_audio_result_t;

typedef struct {
    uint8_t label_id;       // 0=debout, 1=assis, 2=allongé, 3=chute (exemple)
    float   confidence;
} tflm_vision_result_t;

esp_err_t tflm_dual_runtime_init(void);

// Quantisation input (scale/zero_point lus depuis tenseur d'entrée du modèle)
void tflm_quantize_input_audio(const float *in_f32, size_t n, int8_t *out_q);
void tflm_quantize_input_vision(const float *in_f32, size_t n, int8_t *out_q);

esp_err_t tflm_audio_infer(const int8_t *mfcc_input, tflm_audio_result_t *result);
esp_err_t tflm_vision_infer(const int8_t *img_input, tflm_vision_result_t *result);

#ifdef __cplusplus
}
#endif
