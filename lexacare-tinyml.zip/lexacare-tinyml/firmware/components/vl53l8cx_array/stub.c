/**
 * @file stub.c
 * @brief STUB — remplace ce fichier par ton driver ULD porté.
 *
 * Permet au projet de compiler tant que tu n'as pas fini le portage Arduino→IDF.
 * En mode stub, `acquire_frame` retourne une mire synthétique (distances qui
 * varient lentement) pour que la pipeline en aval soit testable sans hardware.
 */

#include "esp_err.h"
#include "esp_log.h"
#include <stdint.h>
#include <stddef.h>
#include "esp_random.h"
#include "../../main/lexa_config.h"

static const char *TAG = "tof_stub";

esp_err_t vl53l8cx_array_init(void)
{
    ESP_LOGW(TAG, "STUB driver — replace with real ULD port");
    return ESP_OK;
}

esp_err_t vl53l8cx_array_acquire_frame(uint16_t distances[LEXA_TOF_TOTAL_PIXELS])
{
    // Mire synthétique : gradient vertical 500-3500 mm + petit bruit
    static uint32_t frame = 0;
    frame++;
    for (int s = 0; s < LEXA_TOF_COUNT; s++) {
        for (int r = 0; r < LEXA_TOF_RESOLUTION; r++) {
            for (int c = 0; c < LEXA_TOF_RESOLUTION; c++) {
                int idx = s * LEXA_TOF_PIXELS_PER_SENSOR + r * 8 + c;
                uint16_t base = 500 + r * 400;                  // gradient Y
                uint16_t noise = (esp_random() & 0x7F);         // ±127 mm
                distances[idx] = base + noise;
            }
        }
    }
    return ESP_OK;
}
