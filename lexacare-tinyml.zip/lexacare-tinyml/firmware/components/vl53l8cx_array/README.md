# components/vl53l8cx_array/

## Intégration de ton driver VL53L8CX existant

Tu as déjà un driver VL53L8CX fonctionnel en Arduino (4 capteurs SPI via NCS multiplexés).
Ce dossier est le **point d'injection** pour le porter en ESP-IDF.

## Interface attendue par `main/task_vision.c`

```c
// Prototype à fournir :
esp_err_t vl53l8cx_array_init(void);
esp_err_t vl53l8cx_array_acquire_frame(uint16_t distances[256]);
// distances[] ligne-majeur : sensor0_8x8 | sensor1_8x8 | sensor2_8x8 | sensor3_8x8
```

## Stratégie de portage Arduino → ESP-IDF

Si tu utilises la **ULD officielle ST** (fichiers `vl53l8cx_api.c`, `vl53l8cx_api.h`,
`platform.h` fournis par ST Microelectronics), le portage est mécanique :

### 1. Copier les fichiers ULD
```
components/vl53l8cx_array/
├── CMakeLists.txt           ← à créer
├── vl53l8cx_api.c           ← depuis ST ULD (ne pas toucher)
├── vl53l8cx_api.h           ← depuis ST ULD
├── vl53l8cx_buffers.h       ← depuis ST ULD
├── platform.c               ← à écrire (ci-dessous)
├── platform.h               ← à écrire (ci-dessous)
└── include/
    └── vl53l8cx_array.h     ← API haut niveau (4 capteurs)
```

### 2. `CMakeLists.txt`
```cmake
idf_component_register(
    SRCS "vl53l8cx_api.c" "platform.c" "vl53l8cx_array.c"
    INCLUDE_DIRS "." "include"
    REQUIRES driver pca9555_io
)
```

### 3. `platform.c` (le seul fichier qui change vs Arduino)

Remplacer les appels Arduino `SPI.transfer()` / `digitalWrite()` par l'API
ESP-IDF `spi_device_transmit()` / `gpio_set_level()`.

Template minimal :

```c
#include "platform.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "../../main/lexa_config.h"

static spi_device_handle_t s_spi = NULL;
static const gpio_num_t s_ncs_pins[LEXA_TOF_COUNT] = {
    LEXA_TOF_NCS_GPIO_0, LEXA_TOF_NCS_GPIO_1,
    LEXA_TOF_NCS_GPIO_2, LEXA_TOF_NCS_GPIO_3
};

// Variable externe pour savoir quel capteur on adresse actuellement
int g_current_tof = 0;

uint8_t VL53L8CX_RdByte(VL53L8CX_Platform *p, uint16_t addr, uint8_t *value) {
    // Addr 16-bit envoyée MSB first, lecture via SPI
    uint8_t tx[3] = { (addr >> 8) & 0x7F, addr & 0xFF, 0 };  // bit7=0 pour read
    uint8_t rx[3] = {0};
    spi_transaction_t t = { .length = 24, .tx_buffer = tx, .rx_buffer = rx };
    gpio_set_level(s_ncs_pins[g_current_tof], 0);
    spi_device_transmit(s_spi, &t);
    gpio_set_level(s_ncs_pins[g_current_tof], 1);
    *value = rx[2];  // ⚠ MISO mirrors MOSI pendant les 16 premiers bits (15-bit addr phase)
    return 0;
}

// Implémenter de la même façon :
//   VL53L8CX_WrByte, VL53L8CX_RdMulti, VL53L8CX_WrMulti,
//   VL53L8CX_WaitMs, VL53L8CX_GetTickCount, VL53L8CX_Reset_Sensor

uint8_t VL53L8CX_WaitMs(VL53L8CX_Platform *p, uint32_t ms) {
    vTaskDelay(pdMS_TO_TICKS(ms));
    return 0;
}
```

### 4. `vl53l8cx_array.c` — logique multi-capteur

Pseudo-code :
```c
esp_err_t vl53l8cx_array_init(void) {
    // 1. init SPI bus avec GPIO de lexa_config.h
    // 2. configurer les 4 NCS en output high
    // 3. reset séquentiel via PCA9555 :
    //    for i in 0..3 :
    //      pca9555_set_all_tof_lpn(false)
    //      pca9555_set_tof_lpn(i, true)
    //      vl53l8cx_init(&dev[i])
    //      vl53l8cx_set_i2c_address(...)  // ou juste mémoriser le handle
    // 4. réactiver tous les capteurs
    return ESP_OK;
}
```

## ⚠️ Pièges connus (déjà documentés dans ta mémoire projet)

1. **GPIO1/GPIO2 sont des strapping pins** — mettre pull-up au boot, sinon
   mauvais mode de flash au reset.
2. **MISO mirror sur la phase d'adresse** — les 16 premiers bits lus sont
   identiques au MOSI (artefact de la phase d'adressage 15-bit). La data utile
   commence à `rx[2]`.
3. **TXB0108PW level-shifter** — limiter la vitesse SPI à ~3 MHz max, au-delà
   les fronts se déforment sur les capacités parasites.
