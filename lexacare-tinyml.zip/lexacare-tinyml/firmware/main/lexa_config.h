/**
 * @file lexa_config.h
 * @brief Configuration centralisée LexaCare V1
 *
 * TOUT paramètre matériel ou temporel passe par ce fichier. Ne JAMAIS
 * hardcoder un GPIO ou une taille de buffer ailleurs dans le code.
 *
 * Analogie : c'est le fichier "device tree" du projet — l'équivalent du
 * `pinctrl` Linux en un header C. Si tu déplaces un signal sur la carte,
 * tu changes ici et nulle part ailleurs.
 */
#pragma once

// ============================================================================
// === HARDWARE — GPIO MAPPING                                              ===
// ============================================================================

// --- I2C bus (PCA9555 pour LPn des 4 ToF) ---
#define LEXA_I2C_SDA_GPIO          11
#define LEXA_I2C_SCL_GPIO          12
#define LEXA_I2C_FREQ_HZ           400000
#define LEXA_PCA9555_ADDR          0x20

// --- SPI bus ToF (commun aux 4 VL53L8CX via NCS distincts) ---
#define LEXA_TOF_SPI_HOST          SPI2_HOST
#define LEXA_TOF_SPI_CLK_GPIO      4
#define LEXA_TOF_SPI_MOSI_GPIO     15
#define LEXA_TOF_SPI_MISO_GPIO     21
#define LEXA_TOF_SPI_FREQ_HZ       3000000   // 3 MHz : limite pratique avec TXB0108PW
#define LEXA_TOF_NCS_GPIO_0        1         // ⚠ strapping pin, init pull-up
#define LEXA_TOF_NCS_GPIO_1        2         // ⚠ strapping pin, init pull-up
#define LEXA_TOF_NCS_GPIO_2        42
#define LEXA_TOF_NCS_GPIO_3        41
#define LEXA_TOF_COUNT             4

// --- I2S micros stéréo ---
#define LEXA_I2S_PORT              I2S_NUM_0
#define LEXA_I2S_BCLK_GPIO         5
#define LEXA_I2S_WS_GPIO           6
#define LEXA_I2S_DIN_GPIO          7
#define LEXA_I2S_SAMPLE_RATE       16000     // 16 kHz (standard KWS)
#define LEXA_I2S_BITS_PER_SAMPLE   I2S_DATA_BIT_WIDTH_16BIT
#define LEXA_I2S_CHANNELS          2         // stéréo L+R
#define LEXA_AUDIO_GAIN_SHIFT      4         // multiplication x16 (cf. Gemini optim)

// ============================================================================
// === AUDIO PIPELINE                                                        ===
// ============================================================================

// Fenêtre d'analyse audio (= durée d'un "frame" alimentant l'IA)
#define LEXA_AUDIO_WINDOW_MS       1000      // 1 seconde
#define LEXA_AUDIO_WINDOW_SAMPLES  (LEXA_I2S_SAMPLE_RATE * LEXA_AUDIO_WINDOW_MS / 1000)
#define LEXA_AUDIO_HOP_MS          250       // inférence toutes les 250ms (overlap 75%)
#define LEXA_AUDIO_HOP_SAMPLES     (LEXA_I2S_SAMPLE_RATE * LEXA_AUDIO_HOP_MS / 1000)

// Ring buffer audio en PSRAM : 3s de marge pour absorber pics de latence
#define LEXA_AUDIO_RING_SECONDS    3
#define LEXA_AUDIO_RING_SAMPLES    (LEXA_I2S_SAMPLE_RATE * LEXA_AUDIO_RING_SECONDS)

// ============================================================================
// === MFCC                                                                  ===
// ============================================================================

// Paramètres MFCC — DOIVENT correspondre EXACTEMENT à tool/trainer/mfcc_reference.py
// Sinon le modèle entraîné en Python ne marchera pas sur l'ESP32.
#define LEXA_MFCC_FRAME_LEN        512       // 32ms @ 16kHz, pow2 pour FFT rapide
#define LEXA_MFCC_FRAME_STEP       160       // 10ms @ 16kHz (hop)
#define LEXA_MFCC_N_FFT            512
#define LEXA_MFCC_N_MELS           40
#define LEXA_MFCC_N_COEFFS         13        // garde 13 premiers coefficients DCT
#define LEXA_MFCC_PREEMPH          0.97f
#define LEXA_MFCC_F_MIN_HZ         20.0f
#define LEXA_MFCC_F_MAX_HZ         (LEXA_I2S_SAMPLE_RATE / 2)   // Nyquist
// Nombre de frames MFCC dans une fenêtre d'1s
#define LEXA_MFCC_N_FRAMES         ((LEXA_AUDIO_WINDOW_SAMPLES - LEXA_MFCC_FRAME_LEN) / LEXA_MFCC_FRAME_STEP + 1)

// ============================================================================
// === ToF / VISION                                                          ===
// ============================================================================

#define LEXA_TOF_RESOLUTION        8         // 8x8 par capteur
#define LEXA_TOF_PIXELS_PER_SENSOR (LEXA_TOF_RESOLUTION * LEXA_TOF_RESOLUTION)  // 64
#define LEXA_TOF_TOTAL_PIXELS      (LEXA_TOF_PIXELS_PER_SENSOR * LEXA_TOF_COUNT) // 256
#define LEXA_TOF_FRAME_RATE_HZ     15        // 15 FPS pour détection de chute
#define LEXA_TOF_PERIOD_MS         (1000 / LEXA_TOF_FRAME_RATE_HZ)

// Disposition des 4 capteurs en paysage 180° :
// [ToF0 | ToF1 | ToF2 | ToF3] = image virtuelle 8x32
#define LEXA_VISION_IMAGE_W        32        // 8 × 4 capteurs
#define LEXA_VISION_IMAGE_H        8

// ============================================================================
// === TFLM — ALLOCATION ARENAS                                              ===
// ============================================================================

// 2 arenas séparées → pas de contention entre les 2 modèles.
// En PSRAM Octal @ 80MHz : latence d'accès +~20% vs SRAM, mais on a la place.
// Tailles à ajuster après compilation des modèles réels (voir `lexacare export`).
#define LEXA_TFLM_ARENA_AUDIO_KB   128
#define LEXA_TFLM_ARENA_VISION_KB  64
#define LEXA_TFLM_ARENA_AUDIO_SIZE (LEXA_TFLM_ARENA_AUDIO_KB * 1024)
#define LEXA_TFLM_ARENA_VISION_SIZE (LEXA_TFLM_ARENA_VISION_KB * 1024)

// ============================================================================
// === FREERTOS — PRIORITÉS ET AFFINITÉS                                     ===
// ============================================================================

// Analogie : tableau de garde d'un hôpital.
//   Core 0 (audio) → "urgences temps-réel" : latence I2S critique, DMA non-stop
//   Core 1 (vision) → "consultations planifiées" : 15 FPS = 66ms de marge
//
// Priorités (plus haut = plus prioritaire, max = configMAX_PRIORITIES-1 = 24) :
#define LEXA_PRIO_AUDIO_DMA        20        // hard real-time (I2S)
#define LEXA_PRIO_AUDIO_MFCC       15        // soft real-time
#define LEXA_PRIO_AUDIO_INFER      12        //
#define LEXA_PRIO_VISION_ACQUIRE   18        // hard real-time (SPI timing)
#define LEXA_PRIO_VISION_INFER     10        //
#define LEXA_PRIO_ORCHESTRATOR     8         // décisions globales
#define LEXA_PRIO_REPORTING        5         // log / alertes réseau

#define LEXA_CORE_AUDIO            0
#define LEXA_CORE_VISION           1

// Stack sizes (en bytes). TFLM inference peut consommer 4-6KB de stack.
#define LEXA_STACK_AUDIO_MFCC      8192
#define LEXA_STACK_AUDIO_INFER     10240
#define LEXA_STACK_VISION_ACQUIRE  4096
#define LEXA_STACK_VISION_INFER    10240
#define LEXA_STACK_ORCHESTRATOR    4096
