/**
 * @file task_capture.c
 * @brief Tâches de capture dataset (compilées uniquement en LEXA_MODE_CAPTURE).
 *
 * Stream brut des données audio et ToF vers le PC via USB CDC (stdout).
 * Format : voir tool/collector/serial_collector.py — frames avec magic+CRC.
 *
 * Comme on est en mode capture, on NE fait pas tourner d'IA : toute la CPU
 * est consacrée à pousser un maximum de data sur le lien USB.
 */

#ifdef LEXA_MODE_CAPTURE

#include <string.h>
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_crc.h"
#include "esp_heap_caps.h"

#include "lexa_config.h"
#include "i2s_stereo_mic.h"
#include "pca9555_io.h"

static const char *TAG = "cap";

// Header frame commun
#define MAGIC_B0 0xA5
#define TYPE_AUDIO 0x01
#define TYPE_TOF   0x02

// Stub pour le driver ToF si pas encore porté
extern esp_err_t vl53l8cx_array_init(void);
extern esp_err_t vl53l8cx_array_acquire_frame(uint16_t distances[LEXA_TOF_TOTAL_PIXELS]);

static void send_frame(uint8_t type, const void *payload, uint32_t length_items,
                       size_t item_bytes)
{
    // Magic (4) + Type (1) + Length (4) + Payload + CRC32 (4)
    uint8_t header[] = { MAGIC_B0, MAGIC_B0, MAGIC_B0, MAGIC_B0,
                          type,
                          (uint8_t)(length_items & 0xFF),
                          (uint8_t)((length_items >> 8) & 0xFF),
                          (uint8_t)((length_items >> 16) & 0xFF),
                          (uint8_t)((length_items >> 24) & 0xFF) };
    fwrite(header, 1, sizeof(header), stdout);

    size_t payload_bytes = length_items * item_bytes;
    fwrite(payload, 1, payload_bytes, stdout);

    uint32_t crc = esp_crc32_le(0, (const uint8_t *)payload, payload_bytes);
    uint8_t crc_buf[4] = {
        (uint8_t)(crc & 0xFF),
        (uint8_t)((crc >> 8) & 0xFF),
        (uint8_t)((crc >> 16) & 0xFF),
        (uint8_t)((crc >> 24) & 0xFF),
    };
    fwrite(crc_buf, 1, 4, stdout);
    fflush(stdout);
}

// ----------------------------------------------------------------------------
void task_capture_audio_entry(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "audio capture started on core %d", xPortGetCoreID());

    // Chunks de 2048 samples stéréo (128ms @ 16kHz) = bon compromis latence/débit
    const size_t chunk_frames = 2048;
    int16_t *buf = heap_caps_malloc(chunk_frames * 2 * sizeof(int16_t), MALLOC_CAP_SPIRAM);
    if (!buf) { ESP_LOGE(TAG, "alloc fail"); vTaskDelete(NULL); return; }

    ESP_ERROR_CHECK(i2s_stereo_mic_init());
    ESP_ERROR_CHECK(i2s_stereo_mic_start());

    vTaskDelay(pdMS_TO_TICKS(500));  // temps de remplir le ring une fois

    while (1) {
        size_t got = i2s_stereo_mic_read_last_window(buf, chunk_frames);
        if (got > 0) {
            send_frame(TYPE_AUDIO, buf, (uint32_t)got, 4);  // 4 bytes par frame stéréo
        }
        vTaskDelay(pdMS_TO_TICKS(chunk_frames * 1000 / LEXA_I2S_SAMPLE_RATE));
    }
}

// ----------------------------------------------------------------------------
void task_capture_vision_entry(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "vision capture started on core %d", xPortGetCoreID());

    uint16_t *raw = heap_caps_malloc(LEXA_TOF_TOTAL_PIXELS * sizeof(uint16_t), MALLOC_CAP_SPIRAM);
    if (!raw) { ESP_LOGE(TAG, "alloc fail"); vTaskDelete(NULL); return; }

    ESP_ERROR_CHECK(vl53l8cx_array_init());

    TickType_t next = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(LEXA_TOF_PERIOD_MS);

    while (1) {
        if (vl53l8cx_array_acquire_frame(raw) == ESP_OK) {
            send_frame(TYPE_TOF, raw, LEXA_TOF_TOTAL_PIXELS, 2);
        }
        vTaskDelayUntil(&next, period);
    }
}

#endif  // LEXA_MODE_CAPTURE
