/**
 * @file task_vision.c
 * @brief Tâche vision Core 1 — 4× VL53L8CX SPI → matrice 8x32 → inférence chute.
 *
 * Le driver VL53L8CX (`components/vl53l8cx_array/`) est à brancher avec le code
 * Arduino existant porté en ESP-IDF. L'interface attendue est dans le .h.
 *
 * Boucle temporelle :
 *   - toutes les 66ms (15 FPS), on interroge les 4 capteurs en SPI
 *   - on assemble une image 8×32 (chaque capteur = colonne 8×8)
 *   - on normalise [0..1] (distance max = 4000mm)
 *   - inférence TFLM → label (debout / allongé / chute en cours / assis)
 */

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"

#include "lexa_config.h"
#include "tflm_dual_runtime.h"
#include "orchestrator.h"

// Interface du driver ToF (à implémenter dans components/vl53l8cx_array/)
extern esp_err_t vl53l8cx_array_init(void);
extern esp_err_t vl53l8cx_array_acquire_frame(uint16_t distances[LEXA_TOF_TOTAL_PIXELS]);

static const char *TAG = "vision";

static uint16_t *s_raw_frame = NULL;       // 256 × uint16 distances mm
static float    *s_norm_frame = NULL;      // 8x32 normalisé [0..1]
static int8_t   *s_q_frame = NULL;         // quantisé pour TFLM

static void normalize_and_reshape(const uint16_t *raw, float *norm)
{
    // Layout visé : image 8×32 ligne-majeur.
    // Les capteurs sont "paysage" : chaque capteur i fournit 8×8 → on le met
    // en tant que bloc 8 lignes × 8 colonnes (colonnes i*8 à i*8+7).
    //
    // Physique : la ligne 0 = en haut (plafond), ligne 7 = en bas (sol).
    // Une chute passe d'un profil "vertical" (pixels haut+bas occupés) à
    // "horizontal" (pixels étalés sur lignes basses).
    const float max_dist_mm = 4000.0f;
    for (int sensor = 0; sensor < LEXA_TOF_COUNT; sensor++) {
        for (int row = 0; row < LEXA_TOF_RESOLUTION; row++) {
            for (int col = 0; col < LEXA_TOF_RESOLUTION; col++) {
                int src_idx = sensor * LEXA_TOF_PIXELS_PER_SENSOR + row * 8 + col;
                int dst_col = sensor * 8 + col;                       // colonne globale
                int dst_idx = row * LEXA_VISION_IMAGE_W + dst_col;
                float v = (float)raw[src_idx] / max_dist_mm;
                if (v > 1.0f) v = 1.0f;
                norm[dst_idx] = v;
            }
        }
    }
}

void task_vision_entry(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "vision task started on core %d", xPortGetCoreID());

    s_raw_frame = heap_caps_malloc(LEXA_TOF_TOTAL_PIXELS * sizeof(uint16_t),
                                    MALLOC_CAP_SPIRAM);
    s_norm_frame = heap_caps_malloc(LEXA_VISION_IMAGE_W * LEXA_VISION_IMAGE_H * sizeof(float),
                                     MALLOC_CAP_SPIRAM);
    s_q_frame = heap_caps_malloc(LEXA_VISION_IMAGE_W * LEXA_VISION_IMAGE_H * sizeof(int8_t),
                                  MALLOC_CAP_SPIRAM);

    if (!s_raw_frame || !s_norm_frame || !s_q_frame) {
        ESP_LOGE(TAG, "PSRAM alloc failed");
        vTaskDelete(NULL);
        return;
    }

    ESP_ERROR_CHECK(vl53l8cx_array_init());

    TickType_t next_wake = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(LEXA_TOF_PERIOD_MS);

    while (1) {
        int64_t t0 = esp_timer_get_time();

        // 1. Acquisition SPI des 4 capteurs
        esp_err_t err = vl53l8cx_array_acquire_frame(s_raw_frame);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "ToF acquire failed: %s", esp_err_to_name(err));
            vTaskDelayUntil(&next_wake, period);
            continue;
        }

        // 2. Normalisation et mise en forme 8x32
        normalize_and_reshape(s_raw_frame, s_norm_frame);

        // 3. Quantisation Int8 pour TFLM
        tflm_quantize_input_vision(s_norm_frame,
                                    LEXA_VISION_IMAGE_W * LEXA_VISION_IMAGE_H,
                                    s_q_frame);

        // 4. Inférence
        tflm_vision_result_t result;
        err = tflm_vision_infer(s_q_frame, &result);

        int64_t t_total = esp_timer_get_time() - t0;

        if (err == ESP_OK) {
            // label_id = index de la classe (ex : 0=debout, 1=assis, 2=allongé, 3=chute)
            if (result.label_id == 3 /* CHUTE */ && result.confidence > 0.7f) {
                lexa_event_t evt = {
                    .type = EVT_FALL_CONFIRMED,
                    .timestamp_ms = (uint32_t)(esp_timer_get_time() / 1000ULL),
                    .confidence = result.confidence,
                    .label_id = result.label_id,
                };
                orchestrator_publish(&evt);
            }
        }

        static int counter = 0;
        if (++counter % 30 == 0) {  // log toutes les 2s (30 × 66ms)
            ESP_LOGI(TAG, "frame %lldµs | label=%u conf=%.2f",
                     t_total, result.label_id, result.confidence);
        }

        vTaskDelayUntil(&next_wake, period);
    }
}
