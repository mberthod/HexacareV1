/**
 * @file task_audio.c
 * @brief Tâche audio Core 0 — I2S → ring buffer → MFCC → inférence KWS.
 *
 * Structure temporelle (en régime stable) :
 *
 *   0ms ─── 250ms ── 500ms ── 750ms ── 1000ms ── 1250ms ─── t
 *   │                                   │
 *   ├── fenêtre 1 (1s) ──────────────── │
 *              ├── fenêtre 2 (1s) ──────────────── │
 *                         ├── fenêtre 3 (1s) ────────────── │
 *
 * On exploite un ring buffer 3s en PSRAM et on fait une inférence toutes les
 * 250ms (hop) sur la dernière seconde → overlap 75%.
 *
 * Analogie : comme un convertisseur sigma-delta où on suréchantillonne puis
 * on filtre. On "suréchantillonne" la décision IA pour ne rater aucun mot-clé
 * même s'il tombe à cheval sur une frontière de fenêtre.
 */

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"

#include "lexa_config.h"
#include "i2s_stereo_mic.h"
#include "mfcc_dsp.h"
#include "tflm_dual_runtime.h"
#include "orchestrator.h"

static const char *TAG = "audio";

// Buffer de travail pour extraire une fenêtre d'1s du ring buffer
// Alloué en PSRAM (trop gros pour la SRAM) via heap_caps.
static int16_t *s_window_buf = NULL;       // LEXA_AUDIO_WINDOW_SAMPLES × int16
static float   *s_mfcc_out  = NULL;        // LEXA_MFCC_N_FRAMES × LEXA_MFCC_N_COEFFS
static int8_t  *s_mfcc_q    = NULL;        // version quantisée Int8 pour TFLM

static void mix_stereo_to_mono_with_gain(const int16_t *stereo_in,
                                          int16_t *mono_out,
                                          size_t n_samples)
{
    // Mixage L+R puis amplification x16 avec clipping — cf. optim ROBO-OMNI Gemini.
    // L'input I2S est entrelacé : [L0 R0 L1 R1 L2 R2 ...]
    for (size_t i = 0; i < n_samples; i++) {
        int32_t mono = ((int32_t)stereo_in[2*i] + (int32_t)stereo_in[2*i + 1]) / 2;
        mono <<= LEXA_AUDIO_GAIN_SHIFT;     // gain x16
        // Clipping hard pour éviter le wrap-around qui casserait complètement l'IA
        if (mono >  32767) mono =  32767;
        if (mono < -32768) mono = -32768;
        mono_out[i] = (int16_t)mono;
    }
}

void task_audio_entry(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "audio task started on core %d", xPortGetCoreID());

    // Allocations PSRAM (les buffers sont gros, pas latence-critique pour l'accès)
    s_window_buf = heap_caps_malloc(LEXA_AUDIO_WINDOW_SAMPLES * sizeof(int16_t) * 2,
                                     MALLOC_CAP_SPIRAM);  // ×2 car stéréo
    s_mfcc_out = heap_caps_malloc(LEXA_MFCC_N_FRAMES * LEXA_MFCC_N_COEFFS * sizeof(float),
                                   MALLOC_CAP_SPIRAM);
    s_mfcc_q = heap_caps_malloc(LEXA_MFCC_N_FRAMES * LEXA_MFCC_N_COEFFS * sizeof(int8_t),
                                 MALLOC_CAP_SPIRAM);

    if (!s_window_buf || !s_mfcc_out || !s_mfcc_q) {
        ESP_LOGE(TAG, "PSRAM alloc failed");
        vTaskDelete(NULL);
        return;
    }

    // Buffer mono intermédiaire (mixage L+R)
    int16_t *mono_buf = heap_caps_malloc(LEXA_AUDIO_WINDOW_SAMPLES * sizeof(int16_t),
                                          MALLOC_CAP_SPIRAM);

    // Démarrer la capture I2S (remplit le ring buffer en continu via DMA)
    i2s_stereo_mic_start();

    // Attendre qu'il y ait assez de données pour la première fenêtre
    vTaskDelay(pdMS_TO_TICKS(LEXA_AUDIO_WINDOW_MS + 50));

    TickType_t next_wake = xTaskGetTickCount();
    const TickType_t hop_ticks = pdMS_TO_TICKS(LEXA_AUDIO_HOP_MS);

    while (1) {
        // 1. Extraire la dernière seconde du ring buffer (stéréo entrelacé)
        size_t n_read = i2s_stereo_mic_read_last_window(
            s_window_buf, LEXA_AUDIO_WINDOW_SAMPLES);

        if (n_read < LEXA_AUDIO_WINDOW_SAMPLES) {
            ESP_LOGW(TAG, "not enough samples yet (%u)", (unsigned)n_read);
            vTaskDelayUntil(&next_wake, hop_ticks);
            continue;
        }

        // 2. Mixer L+R → mono + gain x16
        mix_stereo_to_mono_with_gain(s_window_buf, mono_buf, LEXA_AUDIO_WINDOW_SAMPLES);

        // 3. Calculer le MFCC (40 mel → 13 coeffs × N_FRAMES)
        int64_t t0 = esp_timer_get_time();
        mfcc_dsp_compute(mono_buf, LEXA_AUDIO_WINDOW_SAMPLES, s_mfcc_out);
        int64_t t_mfcc = esp_timer_get_time() - t0;

        // 4. Quantiser float → int8 pour le modèle Int8
        //    (scale et zero_point viennent du modèle TFLite — voir tflm_dual_runtime)
        tflm_quantize_input_audio(s_mfcc_out,
                                   LEXA_MFCC_N_FRAMES * LEXA_MFCC_N_COEFFS,
                                   s_mfcc_q);

        // 5. Inférence TFLM
        t0 = esp_timer_get_time();
        tflm_audio_result_t result;
        esp_err_t err = tflm_audio_infer(s_mfcc_q, &result);
        int64_t t_inf = esp_timer_get_time() - t0;

        if (err == ESP_OK && result.confidence > 0.6f && result.label_id > 0) {
            // label_id 0 = "silence/unknown" par convention
            lexa_event_t evt = {
                .type = EVT_VOICE_KEYWORD,
                .timestamp_ms = (uint32_t)(esp_timer_get_time() / 1000ULL),
                .confidence = result.confidence,
                .label_id = result.label_id,
            };
            orchestrator_publish(&evt);
        }

        // Log périodique (toutes les 4 inférences = 1s)
        static int counter = 0;
        if (++counter % 4 == 0) {
            ESP_LOGI(TAG, "MFCC %lldµs | inf %lldµs | label=%u conf=%.2f",
                     t_mfcc, t_inf, result.label_id, result.confidence);
        }

        vTaskDelayUntil(&next_wake, hop_ticks);
    }
}
