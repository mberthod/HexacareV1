/**
 * @file orchestrator.h
 * @brief Corrélation des événements audio + vision, gestion des alertes.
 *
 * Analogie : c'est le "superviseur" d'une salle de contrôle. Les capteurs
 * (audio, vision) lui remontent des "candidats alerte" ; lui décide si c'est
 * une vraie alerte en croisant les infos dans une fenêtre temporelle donnée.
 */
#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "esp_err.h"

typedef enum {
    EVT_NONE = 0,
    EVT_FALL_DETECTED,          // vision : posture allongée anormale
    EVT_FALL_CONFIRMED,         // vision : chute en cours
    EVT_VOICE_KEYWORD,          // audio : mot-clé reconnu
    EVT_LOUD_NOISE,             // audio : pic de volume (non-IA)
    EVT_ALERT_RAISED,           // décision finale
} lexa_event_type_t;

typedef struct {
    lexa_event_type_t type;
    uint32_t timestamp_ms;      // esp_timer_get_time / 1000
    float    confidence;        // [0..1] — score modèle ou amplitude
    uint8_t  label_id;          // index classe pour KWS / vision
} lexa_event_t;

// Handle de la queue globale (vision + audio publient, orchestrator consomme)
extern QueueHandle_t g_event_queue;

esp_err_t orchestrator_init(void);

// Publication non bloquante depuis n'importe quelle tâche.
// Retourne false si la queue est pleine (event drop — signaler dans les logs).
bool orchestrator_publish(const lexa_event_t *evt);
