/**
 * @file orchestrator.c
 * @brief Machine à états de corrélation audio+vision.
 *
 * Règle de décision (V1, à affiner avec des vraies données terrain) :
 *   ALERTE = (chute vision confirmée) ET (mot-clé ou bruit fort dans les 5s)
 *
 * Ça évite les faux positifs :
 *   - Quelqu'un qui s'allonge sur le canapé → chute détectée, mais aucun bruit
 *     → pas d'alerte.
 *   - Quelqu'un qui crie → bruit fort, mais pas de posture allongée
 *     → pas d'alerte.
 *
 * Les deux modalités se valident mutuellement.
 */

#include "orchestrator.h"
#include "lexa_config.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "orch";

QueueHandle_t g_event_queue = NULL;

// État interne du superviseur
typedef struct {
    uint32_t last_fall_ms;
    uint32_t last_voice_ms;
    uint32_t last_loud_ms;
    float    last_fall_conf;
    bool     alert_active;
} orch_state_t;

static orch_state_t s_state = {0};

#define LEXA_CORRELATION_WINDOW_MS  5000    // 5s
#define LEXA_ALERT_COOLDOWN_MS      30000   // pas de re-déclenchement < 30s
#define LEXA_FALL_MIN_CONFIDENCE    0.75f

esp_err_t orchestrator_init(void)
{
    // Queue taille 16 — largement assez, les events sont rares
    g_event_queue = xQueueCreate(16, sizeof(lexa_event_t));
    if (!g_event_queue) return ESP_ERR_NO_MEM;
    return ESP_OK;
}

bool orchestrator_publish(const lexa_event_t *evt)
{
    if (!g_event_queue || !evt) return false;
    // Non-bloquant : si la queue est pleine on drop (orchestrator doit vider).
    return xQueueSend(g_event_queue, evt, 0) == pdTRUE;
}

static void raise_alert(uint32_t now_ms, float fall_conf)
{
    if (s_state.alert_active) return;  // déjà actif
    if (now_ms - s_state.last_fall_ms > LEXA_ALERT_COOLDOWN_MS &&
        s_state.alert_active == false) {
        // cooldown dépassé → on peut re-déclencher
    }
    s_state.alert_active = true;
    ESP_LOGW(TAG, "*** ALERTE CHUTE + APPEL DÉTECTÉS *** conf=%.2f", fall_conf);
    // TODO : pousser event EVT_ALERT_RAISED vers module réseau / GPIO / UART
}

static void evaluate_correlation(uint32_t now_ms)
{
    uint32_t dt_fall  = now_ms - s_state.last_fall_ms;
    uint32_t dt_voice = now_ms - s_state.last_voice_ms;
    uint32_t dt_loud  = now_ms - s_state.last_loud_ms;

    bool recent_fall  = (dt_fall  < LEXA_CORRELATION_WINDOW_MS) &&
                        (s_state.last_fall_conf >= LEXA_FALL_MIN_CONFIDENCE);
    bool recent_audio = (dt_voice < LEXA_CORRELATION_WINDOW_MS) ||
                        (dt_loud  < LEXA_CORRELATION_WINDOW_MS);

    if (recent_fall && recent_audio) {
        raise_alert(now_ms, s_state.last_fall_conf);
    }
}

void task_orchestrator_entry(void *arg)
{
    (void)arg;
    ESP_LOGI(TAG, "orchestrator started on core %d", xPortGetCoreID());

    lexa_event_t evt;
    while (1) {
        if (xQueueReceive(g_event_queue, &evt, pdMS_TO_TICKS(1000)) == pdTRUE) {
            uint32_t now = (uint32_t)(esp_timer_get_time() / 1000ULL);

            switch (evt.type) {
                case EVT_FALL_CONFIRMED:
                    s_state.last_fall_ms = evt.timestamp_ms;
                    s_state.last_fall_conf = evt.confidence;
                    ESP_LOGI(TAG, "fall event conf=%.2f", evt.confidence);
                    break;
                case EVT_VOICE_KEYWORD:
                    s_state.last_voice_ms = evt.timestamp_ms;
                    ESP_LOGI(TAG, "keyword #%u conf=%.2f", evt.label_id, evt.confidence);
                    break;
                case EVT_LOUD_NOISE:
                    s_state.last_loud_ms = evt.timestamp_ms;
                    break;
                default:
                    break;
            }

            evaluate_correlation(now);
        } else {
            // Timeout sans event — vérifier quand même si le cooldown d'alerte expire
            if (s_state.alert_active) {
                uint32_t now = (uint32_t)(esp_timer_get_time() / 1000ULL);
                if (now - s_state.last_fall_ms > LEXA_ALERT_COOLDOWN_MS) {
                    s_state.alert_active = false;
                    ESP_LOGI(TAG, "alerte acquittée (cooldown)");
                }
            }
        }
    }
}
