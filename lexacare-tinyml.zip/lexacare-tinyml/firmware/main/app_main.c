/**
 * @file app_main.c
 * @brief Point d'entrée LexaCare V1 — création des tâches dual-core.
 *
 * Stratégie :
 *   - main_task (Core 0) : init matériel séquentiel, puis création des tâches
 *   - task_audio (Core 0) : pipeline I2S → ring buffer → MFCC → inférence voix
 *   - task_vision (Core 1) : pipeline SPI → matrice 8x32 → inférence chute
 *   - task_orchestrator (Core 0, prio basse) : corrélation + alertes
 *
 * Pourquoi ce découpage : l'I2S DMA interrompt constamment. En pinnant l'audio
 * sur Core 0 et la vision sur Core 1, on garantit que les interruptions DMA
 * ne font pas de jitter sur la boucle SPI ToF (qui a des timings serrés).
 */

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "esp_psram.h"

#include "lexa_config.h"
#include "i2s_stereo_mic.h"
#include "mfcc_dsp.h"
#include "tflm_dual_runtime.h"
#include "pca9555_io.h"
#include "orchestrator.h"

static const char *TAG = "lexa_main";

// Prototypes des tâches (définies dans task_audio.c / task_vision.c)
extern void task_audio_entry(void *arg);
extern void task_vision_entry(void *arg);
extern void task_orchestrator_entry(void *arg);

static void print_memory_status(void)
{
    ESP_LOGI(TAG, "=== Memory status ===");
    ESP_LOGI(TAG, "Internal free : %u bytes", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL));
    ESP_LOGI(TAG, "PSRAM free    : %u bytes", (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    ESP_LOGI(TAG, "PSRAM size    : %u bytes", (unsigned)esp_psram_get_size());
}

void app_main(void)
{
    ESP_LOGI(TAG, "\n\n========================================");
    ESP_LOGI(TAG, "  LexaCare V1 — ELEC-CORE Projet 054");
    ESP_LOGI(TAG, "========================================\n");

    // --- Vérifier que la PSRAM Octal est bien montée ---
    if (esp_psram_get_size() < 8 * 1024 * 1024) {
        ESP_LOGE(TAG, "PSRAM < 8MB — vérifier sdkconfig SPIRAM_MODE_OCT");
        abort();
    }
    print_memory_status();

    // ========================================================================
    // 1. INIT MATÉRIEL (séquentiel, avant de lancer les tâches)
    // ========================================================================

    // PCA9555 d'abord : il contrôle les LPn des ToF. Les ToF doivent être
    // tous en LPn haut au démarrage pour pouvoir les adresser un par un.
    ESP_ERROR_CHECK(pca9555_init());
    pca9555_set_all_tof_lpn(true);   // tous allumés

    // I2S micros stéréo — alloué en PSRAM pour le ring buffer
    ESP_ERROR_CHECK(i2s_stereo_mic_init());

    // MFCC — précalcule les coefficients Mel (une fois pour toutes)
    ESP_ERROR_CHECK(mfcc_dsp_init());

    // TFLM — alloue les 2 arenas en PSRAM
    ESP_ERROR_CHECK(tflm_dual_runtime_init());

    // Orchestrator — crée les queues et sémaphores partagés
    ESP_ERROR_CHECK(orchestrator_init());

    print_memory_status();
    ESP_LOGI(TAG, "Hardware init OK, launching tasks...");

    // ========================================================================
    // 2. CRÉATION DES TÂCHES — avec pinning explicite sur les cores
    // ========================================================================

#if defined(LEXA_MODE_INFERENCE)
    // --- Core 0 : Audio + Orchestration ---
    xTaskCreatePinnedToCore(
        task_audio_entry,                // fonction
        "audio",                         // nom
        LEXA_STACK_AUDIO_INFER,          // stack
        NULL,                            // arg
        LEXA_PRIO_AUDIO_MFCC,            // prio
        NULL,                            // handle (on ne le garde pas)
        LEXA_CORE_AUDIO);                // core

    xTaskCreatePinnedToCore(
        task_orchestrator_entry, "orch",
        LEXA_STACK_ORCHESTRATOR, NULL,
        LEXA_PRIO_ORCHESTRATOR, NULL,
        LEXA_CORE_AUDIO);

    // --- Core 1 : Vision ---
    xTaskCreatePinnedToCore(
        task_vision_entry, "vision",
        LEXA_STACK_VISION_INFER, NULL,
        LEXA_PRIO_VISION_ACQUIRE, NULL,
        LEXA_CORE_VISION);

    ESP_LOGI(TAG, "Running in INFERENCE mode");
#elif defined(LEXA_MODE_CAPTURE)
    // En mode capture, on ne fait PAS d'inférence : on stream brut par USB CDC
    // vers le PC qui enregistre le dataset via `lexacare collect`.
    extern void task_capture_audio_entry(void *arg);
    extern void task_capture_vision_entry(void *arg);
    xTaskCreatePinnedToCore(task_capture_audio_entry, "cap_a", 8192, NULL, 10, NULL, 0);
    xTaskCreatePinnedToCore(task_capture_vision_entry, "cap_v", 8192, NULL, 10, NULL, 1);
    ESP_LOGI(TAG, "Running in CAPTURE mode — streaming dataset over USB CDC");
#else
    #error "Must define LEXA_MODE_INFERENCE or LEXA_MODE_CAPTURE in platformio.ini"
#endif

    // main_task n'a plus rien à faire, on peut le laisser en veille.
    // Il pourrait être supprimé mais on le garde vivant pour pouvoir
    // ajouter plus tard des commandes via console série.
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(5000));
        ESP_LOGI(TAG, "heartbeat — heap internal=%u  spiram=%u",
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                 (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    }
}
